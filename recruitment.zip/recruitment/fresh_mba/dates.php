           <!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Importand Dates</title>
<style>
.login {
	display:none;
}
#loginbox{
	display:none;
	text-align:center;
	margin:65px 7px -25px 5px;
	padding:25px 5px 15px 55px;
	background:#fff;
	color:#b22d00;
	-moz-border-radius:6px;
	-webkit-border-radius:6px;
}
.submit{
	height:20px;
	width:80px;
}
td,table{
	border-color:#23527c;
}
</style>
</head>

<body>
<div id="main" style="font-size:13px; margin:0px 0 0 0;" align="justify">

<center><b style="font-size:18px">Important Dates </b>
<hr />
<br /><br />
<table border="1px"> 
<tr>
<td>Start of online filling of Application Form	</td>
<td>December 15, 2016; Thursday</td>
</tr>
<tr>
<td>Last date for filling online application</td>
<td>February 15, 2017 (up to 11.59 PM for

online fee submission. For offline fee

submission up to bank timing)</td>
</tr>
<tr>
<td><s>Last date for Submission of Form after filling online</s></td>
<td><s>February 07, 2017; Tuesday (up to 5:30 PM)</s></td>
</tr>
<tr>
<td>Declaration of short listed candidates for GD and PI</td>
<td>February 20, 2017; Monday</td>
</tr>
<tr>
<td>Date of GD/PI</td>
<td>March 05, 2017; Sunday</td>
</tr>
<tr>
<td>Declaration of Merit List</td>
<td> March 16, 2017; Thursday</td>

<!--<td><p>Result Declared</p><a class="leftnav" href="./data/.pdf"></a></td>-->
</tr>
<tr>
<td>Last date for submission of semester fee</td>
<td> March 30, 2017; Thursday</td>
</tr>
<tr>
<td>Declarartion of second list for admission (in case of vacancy)</td>
<td> April 03, 2017; Monday</td>
</tr>
<tr>
<td>Last date for submission of semester fee</td>
<td> April 17, 2017; Monday</td>
</tr>
<tr>
<td>Declaration of third list for admission/declaration for spot round (in case of vacancy)</td>
<td>April 19, 2017; Monday</td>
</tr>

<tr>
<td>Commencement of Classes</td>
<td>July 17, 2017; Monday</td>
</tr>
<!--
<tr>
<td>Last date for submission of semester fee</td>
<td>July 04, 2015; Saturday</td>
</tr>
<tr>
<td>Declaration of vacant seats for spot admission (in case of vacant seats existing) </td>
<td>July 07, 2015; Tuesday</td>
</tr>
<tr>
<td>Spot round [for the candidates who had applied online/appeared in GD/PI]</td>
<td>July 15, 2015; Wednesday</td>
</tr> -->
</table>
</center>
 <br />
</div>
</body>
</html>           