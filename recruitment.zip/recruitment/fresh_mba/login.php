<center>
<b style="font-size:18px;">Login</b>
<hr />
<br>
</center>
<form action="<?= $_SERVER["PHP_SELF"] ?>" method="post">
  <div class="form-group">
    <label for="roll">CAT Roll No.:</label>
    <input type="text" name="roll" class="form-control" id="email" required>
  </div>
  <div class="form-group">
    <label for="pwd">Password:</label>
    <input type="password" name="pass" class="form-control" id="pwd" required>
  </div>
  <button type="submit" class="btn btn-primary" name="req_login" >Submit</button>
</form>
<hr>
<p class="larger-font <?php if( isset($login_error) && $login_error) { echo "text-danger";} else { echo "text-success";} ?>">
	<?php 
		if( isset($login_error) && $login_error) 
		{
			?>
            <strong>Login attempt failed!</strong>
            <?php 
		} 
		else 
		{ 
			?>
            <strong>Login with your credentials.</strong>
            <?php
		} 
	?>
	
</p>
