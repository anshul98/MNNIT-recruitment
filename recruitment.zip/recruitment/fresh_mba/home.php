    <noscript>Please turn on Javascript to continue.</noscript>
    
<?php
session_start();
require_once ('../included_classes/class_sql.php');
require_once ('../included_classes/class_user.php');
require_once ('../included_classes/class_misc.php');
if(!isset($_SESSION['roll']))
{
	echo "<script>window.location=\"./index.php\"</script>";
	die();
}
$sq=new sqlfunctions();
$misc=new miscfunctions();
$sq->connect_db("mba_fresh");
	$conn=mysql_connect("localhost","root","914passwd") or die(error1);
		mysql_select_db('mba_fresh',$conn) or die(dsf);
		 $regno=$_SESSION['roll'];
		$errorInUploading=0;
		
		if($_POST['upload']=="  Upload  ")
		{
			if(isset($_FILES['image']))
			 		include("upapp.php");
			if(isset($_FILES['sign']))
			 		include("sign_upapp.php");
		}
		if($errorInUploading!=0)
		{
			$misc->palert("One or more of your images could NOT be Uploaded. Please contact the webteam","");
		}
	
	
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" ="text/html; charset=utf-8" />
<title>Dean Academics, MNNIT Allahabad</title>

<link rel="stylesheet" type="text/css" href="../sddm.css" >
<link href="style_test_bk.css" rel="stylesheet" type="text/css" />
<link rel="icon" href="images/MNNIT1.ico" />


<script type="text/javascript">

  var _gaq = _gaq || [];
  _gaq.push(['_setAccount', 'UA-20513375-1']);
  _gaq.push(['_trackPageview']);

  (function() {
    var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
    ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
    var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
  })();

</script>


</head>

<body style="overflow-x:hidden;">
<div id="headerbg">
  <div id="headerblank">
    <div id="header">
      <div id="menu">
        <ul>
         
        </ul>
      </div>
      
    </div>
  </div>
</div>

<div id="head_bot">
</div>
<div id="contentbg">
  <div id="contentblank">
  
    <div id="content">
     <!--<div id="contentleft"> 
     asasas
        <?php //$misc->getUpdates();
        ?>
       </div>-->
 	</div>
    
 <div id="contentrightblank" style="float:right; margin-right:50px;">
      <div id="implinks" >
        <div class="rightheading" align="center">
          <div class="heading">Menu</div>
        </div><br />


       
        
<div id="leftnav" >
	
	<ul>
	
	   
	    <li><a class="leftnav" name="profile" href="./printfrm.php" >Print Form</a></li>
		<li><a class="leftnav" id="midframe" href="./home.php">Submit Fee Detail</a></li>
        <?php  $q="select step from step where roll=\"$_SESSION[roll]\"";
		$ss=$sq->get_value("step","step","roll",$_SESSION['roll']);
		
		
		if($ss!="1"){?>
        <!--	<li><a class="leftnav" id="midframe" href="./edit.php">Edit Detail</a></li> -->
            <?php  }?>
        	<li><a class="leftnav" id="midframe" href="./logout.php">logout</a></li>
		
		</ul>
        

	 </div></div>
    </div>
  </div></div>

<div id="contentrightblank" style="margin-top:-180px; margin-left:180px; ">
      <div id="implinks">
        <div class="rightheading" align="center">
          <div class="heading">Contents</div>
        </div><br />


       
        
<div id="leftnav">
	
	<ul>
		<li><a class="leftnav" name="profile" href="./index.php" >Home</a></li>
	    <li><a class="leftnav" name="profile" href="./index.php?val=elb" >Eligiblity</a></li>
		<li><a class="leftnav" id="midframe" href="./index.php?val=intake">Intake</a></li>
        <li><a class="leftnav" id="midframe" href="./index.php?val=res">Reservation</a></li>
        <li><a class="leftnav1" id="midframe" href="./index.php?val=app">Application Procedure</a></li>
        <li><a class="leftnav1" id="midframe" href="./index.php?val=sul">Selection Procedure</a></li>
        <li><a class="leftnav" id="midframe" href="./index.php?val=date">Important Dates</a></li>
        <li><a class="leftnav" id="midframe" href="./index.php?val=contact">Contacts</a></li>
		
		</ul>
        

	 </div></div>
    </div>


      <div id="contentmid">
		  <div class="midtxt" align="left" style=" font-size:14px;  margin-right:-60px;z-index:99; " >
		        <?php 
				$flag=0;
				if($_GET['val']=="nuser")
				{
					//$misc->palert("hi","./index.php");
					include("./frmmba.php");
					$flag=1;
				//	echo "</div>";	
				}
				else if($_GET['val']=="feeinst")
				{
					include("./feeinstruction.php");echo "</div>";
				}
			else if($_GET['val']=="elb"||isset($_POST['submit']))
				{include("./eligiblity.php");
				echo "</div>";}
				else  if($_GET['val']=="download"||isset($_POST['Login']))
				{include("download.php");echo "</div>";}
				else  if($_GET['val']=="elb"||isset($_POST['Login']))
				{include("eligiblity.php");echo "</div>";}
				else  if($_GET['val']=="intake"||isset($_POST['Login']))
				{include("intake.php");echo "</div>";}
				else  if($_GET['val']=="res"||isset($_POST['Login']))
				{include("reservation.php");echo "</div>";}
				else  if($_GET['val']=="app"||isset($_POST['Login']))
				{include("app.php");echo "</div>";}
				else  if($_GET['val']=="sul"||isset($_POST['Login']))
				{include("sul.php");echo "</div>";}
				else  if($_GET['val']=="date"||isset($_POST['Login']))
				{include("dates.php");echo "</div>";}
				else  if($_GET['val']=="contact"||isset($_POST['Login']))
				{include("contact.php");echo "</div>";}
				else { if(isset($_SESSION['roll']))
			{$qr="select id from mba_fresh.formid where roll=\"$_SESSION[roll]\"";
			//echo $qr;
			$qp=mysql_query($qr) or die(er);
			$ar=mysql_fetch_array($qp);
			$_SESSION['appid']=$ar[0];
			//print_r($ar);
			//echo "<center>your Form Id Is </center><br><center><font color=\"#006633\" size=\"+3\">$ar[0]</font><center>";
			
			?>
            <form action="" method="post"  enctype="multipart/form-data">
            <table border="0"  align="left" cellpadding="0" cellspacing="0">
<tr><td colspan="3"><br />
<br />
</td></tr>
  <tr>
  
  <td width="50%" align="center" rowspan="5"><div style="margin-top:0px; position:relative; height:100%; width:100%; padding-top:5px;"><?php echo '<img src="./photos/'.$_SESSION['roll'].'.JPG" alt = "Photo not in Records Please Upload Your Photo" style=\"margin-top:20px; height=180; border-width:thin;\" width="150" height="210" />'; ?><br />
	<div align="center"><input type="file"  name="image" /><input align="" class="button"  style="height:25px" type="submit" value="  Upload  " name="upload" /><br /><font style="font-size:10px;">
Please upload your photo only in JPG format and refresh the page after uploading the photo.</font>
</div>
</div>
</td>
    <td width="50%" align="center" rowspan="5"><div style="margin-top:0px; position:relative; height:100%; width:100%; padding-top:5px;"><?php echo '<img src="./signature/'.$_SESSION['roll'].'.JPG" alt = "Signature not in Records Please Upload Your Signature" style=\"margin-top:20px; height=180; border-width:thin;\" width="150" height="210" />'; ?><br />
	<div align="center"><input type="file"  name="sign" /><input align="" class="button"  style="height:25px" type="submit" value="  Upload  " name="upload" /><br /><font style="font-size:10px;">
Please upload your signature only in JPG ( with file size not exceeding 20KB ) format and refresh the page after uploading it.</font>
</div>
</div>
</td>
	
 
    </tr>
</table>
</form>

        <?php  echo "<center style=\"padding-top:300px;\"><hr><font size=\"+1\">Your Form Id:- </font></center><br><center><font color=\"#006633\" size=\"+2\">$ar[0]</font><center>"  ?>
				<?php include("pay.php");
			}
				else{ echo "<script>window.location=\"./index.php\"</script>";
				die(1);}
				}?>
                
                            <br />
<br />
<br />
<br />
<br />
<br />
<br />
<br />
				</div>
			 
			 
</div>
 </div>
</div>
<?php $misc->getFooter();?>
</body>
</html>
    