<?php
include_once('include/sql_func.php');
include_once('include/sql_functions.php');
include_once('include/misc_functions.php');
//if(isset($_SESSION['logged']))
echo "<script>alert('Registration has been closed!!!');</script>";
	redirect("index.php");
?>
<center><b style="font-size:18px;">Registration Form</b></center><hr>
<br>
<p align="justify" class="larger-font"> 
<ul>
<li>This form asks for the basic details required to start your registration process.</li>
<li>Once your login credentials have been established you can use them to login and fill-in further information required for admission.</li>
<li>You can fill the form in multiple sessions. Information stored from previous sessions will be preserved.</li>
<li><strong>All fields below are mandatory and will not be changed later on.</strong></li>
</ul>
<script>
function validate(){
	if($('#pass').val()!=$('#conf_pass').val()){
		alert("Passwords don't match!");
		$('#pass').val('');
		$('#conf_pass').val('');
		return false;	
	}
	return true;
}
</script>
<hr >
<form class="form-horizontal" name="reg_frm" method="post" action="<?= $_SERVER['PHP_SELF'] ?>" onSubmit="return validate();">
  <div class="form-group">
    <label class="control-label col-sm-3" for="email">CAT Roll No.:</label>
    <div class="col-sm-9">
      <input type="text" class="form-control" id="email" placeholder="Enter Your CAT Roll No." name="reg_roll" required><br>
      <p class="text-danger">Check that your Roll No. is correct as it may not be changed later on.</p>
    </div>
  </div>
  <div class="form-group">
    <label class="control-label col-sm-3" for="email">Candidate Name:</label>
    <div class="col-sm-9">
      <input type="text" class="form-control" id="email" placeholder="Enter Your Name" name="reg_name" required>
    </div>
  </div>
  <div class="form-group">
      <label class="control-label col-sm-3" for="dob">Date of Birth:</label>  
      <div class="col-sm-5">
      <input id="dob" name="reg_dob" placeholder="YYYY-MM-DD" class="form-control input-md" required type="text" title="YYYY-MM-DD">
      </div>
  </div>
 <div class="form-group">
    <label class="control-label col-sm-3" for="email">Password:</label>
    <div class="col-sm-9">
      <input type="password" class="form-control" id="pass" placeholder="Enter Password" name="reg_pass" required><br>
      <p class="text-danger">Remember your password as it may not be changed later on.</p>
    </div>
  </div>
  <div class="form-group">
    <label class="control-label col-sm-3" for="email">Confirm Password:</label>
    <div class="col-sm-9">
      <input type="password" class="form-control" id="conf_pass" placeholder="Confirm Password"  required>
    </div>
  </div>
  <div class="form-group"> 
    <div class="col-sm-offset-4 col-sm-4">
      <button type="submit" name="req_reg" class="btn btn-primary col-sm-12">Submit Details &amp; Register</button>
    </div>
  </div>
</form>
</p>