             <!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Reservation</title>
<style>
.login {
	display:none;
}
#loginbox{
	display:none;
	text-align:center;
	margin:65px 7px -25px 5px;
	padding:25px 5px 15px 55px;
	background:#fff;
	color:#b22d00;
	-moz-border-radius:6px;
	-webkit-border-radius:6px;
}
.submit{
	height:20px;
	width:80px;
}
</style>
</head>

<body>
<div id="main" style="font-size:13px; margin:0px 0 0 0;" align="justify">
  		<?php 
			//include('com_header.php'); 
		?>

<center><b style="font-size:18px;">Application Procedure</b></center>
<hr />
<br />
<span class="larger-font">
Applicants are required to submit their application through this on-line application system only. “No

other means of application shall be acceptable”. 
<br><br>
There are two steps in online application procedure:
<br><br>
<b><em><u>Step 1.</u></em> </b>Register by filling personal details . An application ID will be provided in this step. Note down

carefully this ID for subsequent steps.
<br><br>
<b><em><u>Step 2.</u></em></b> Online filling of application form: Use application ID obtained in step I and date of birth to

login. Before starting the online filling of application form, please make sure that you have soft copy of

your passport size photograph in JPEG (up to 30 kb) format and signature in JPEG format (up to

20kB). 
<br><br>
Pay fee by SBI-MOPS (either online payment by internet banking, credit card/debit card or offline

payment by chalan) Application fee is Rs.1200/- for OP and OBC candidates and Rs.600/-for SC/ST

candidates.
<br><br>
After login, follow the instructions for filling application form. Take print out the form, paste same

photograph which was uploaded, attach all required documents and send on the address given

below:
<br><br />
<div class="well">
Admission Cell,<br>
Office of the Dean (Academic),<br>
Motilal Nehru National Institute of Technology Allahabad Allahabad – 211 004<br>
Write on the top of the envelop “Application for admission in M.B.A. programme; Session 2017-18.
</div>
  <br />
</p>
<center><b style="font-size:18px;">INSTITUTE FEE</b></center>
<hr />
<table border="1px">
<tr >
<td style="border-color:#23527c;">Total fee excluding mess charges</td>
<td style="border-color:#23527c;">1st Semester</td>
<td style="border-color:#23527c;">2nd Semester</td >
<td style="border-color:#23527c;">3rd Semester</td>
<td style="border-color:#23527c;">4th Semester</td>
</tr>
<tr>
<td style="border-color:#23527c;">&nbsp;</td>
<td style="border-color:#23527c;">Rs. 28,176/-</td>
<td style="border-color:#23527c;">Rs. 25,625/-</td>
<td style="border-color:#23527c;">Rs. 26,376/-</td>
<td style="border-color:#23527c;">Rs. 25,625/-</td>

</tr>
</table>
</center>
</span>
</div>
</body>
</html>             