             <!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Refund Policy of the Institute</title>
<style type="text/css">
.Refund {
	color: #8080FF;
}
.Refund {
	color: #8080FF;
}
</style>
</head>

<body>
<div id="main" style="font-size:13px; margin:0px 0 0 0;" align="justify">
			<?php
	  			//include('com_header.php');
			?>
<center><b style="font-size:18px">Refund Policy of the Institute</b></center><br />
<ul class="nav nav-tabs blue-border">
  <li class="active"><a data-toggle="tab" href="#home1" id="pg1">Page - 1</a></li>
  <li><a data-toggle="tab" href="#menu1" id="pg2">Page - 2</a></li>
</ul>
<div class="tab-content">
      <div id="home1" class="tab-pane fade in active">
        <p class="larger-font"><br />
        As per Letter No.14-4/2007- U.3(A) of GoI, Ministry of Human Resource Development, Department of Higher Education [U.3 (A) Section] Following is the refund policy for Institute fee of the Institute for the students who withdraw their admission:<br><br>
		<em><strong>Case 1.</strong></em> In case, a candidate withdraws his/her admission after the close of admission process, no fee except the caution money will be	refunded to him/her.<br><br>
		<em><strong>Case 2.</strong></em> In case, a candidate withdraws his/her admission before the
start of registration but before the close of admission process fee deposited by him/her may be refunded after deduction of &#8377 1000.00 as processing charge.<br><br>
		<em><strong>Case 3.</strong></em> In case, a candidate withdraws his/her admission after the commencement of classes but before the close of admission process; fees deposited by him/her may be refunded after proportionate deduction of monthly charges.<br><br></p>
  	</div>
    
    <div id="menu1" class="tab-pane fade">
        <p class="larger-font"><br />
        	<ul>
			<em><strong>Note:</strong></em><br><br>
			<li> Above provisions are applicable to only Institute fees including tuition fess.</li><br>
			<li> Candidate have to write application for the refund to ‘Dean [Academic] Motilal Nehru National Institute of Technology Allahabad - 211004’ with photocopy of admission letter and draft/e-receipt. E-mail will not be entertained. Date of receipt of application will be valid for calculation of refund.</li><br>
			<li> Please provide following details also in the application form for e-transfer of refunded amount:</li><br>
<strong>NAME :<br>

COMPLETE BANK ACCOUNT No :<br>

BANK NAME :<br>

BANK BRANCH ADDRESS :<br>

BANK IFS CODE :<br>

PERMANENT ACCOUNT NUMBER

[PAN] :<br>

CONTACT NUMBER [For SMS] :<br>

E-MAIL ID [For Information] :<br><br></strong>

<li> If a candidate is admitted in the Institute, he/she shall enclose NO

DUES Certificate also with the application.</li><br>

<li> Original documents will be returned only after completion of all

formalities.</li><br>

<li> Separate application is required for refund of hostel fee/mess fee.<br></li>

Please refer hostel rules.
</ul>
	</p>
  	</div>
</div>
</div>
</body>
</html>             