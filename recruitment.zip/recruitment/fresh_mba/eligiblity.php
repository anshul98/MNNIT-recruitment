    <!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Eligiblity</title>
<style>
.login {
	display:none;
}
#loginbox{
	display:none;
	text-align:center;
	margin:65px 7px -25px 5px;
	padding:25px 5px 15px 55px;
	background:#fff;
	color:#b22d00;
	-moz-border-radius:6px;
	-webkit-border-radius:6px;
}
.submit{
	height:20px;
	width:80px;
}
</style>
</head>

<body>
<div id="main" style="font-size:13px; margin:0px 0 0 0;" align="justify">
<center style="font-size:18px"><b>ELIGIBILITY</b></center>
<hr />
<br />
<ul class="larger-font">
<li>The candidate must have a Bachelor&#39;s degree or equivalent of minimum three years duration in any

discipline, with at least 60% marks or CPI 6.5 [55% or CPI 6.0 in case of candidates belonging to

Scheduled Caste (SC), Scheduled Tribe (ST) and Differently Abled (DA) (this may also referred to as

Persons with Disability (PWD) category)]. 
</li><br />

<li>Candidates appearing for the final year of bachelor&#39;s degree/equivalent qualification examination

and those who have completed degree requirements and are awaiting results can also apply. If

selected, such candidates will be allowed to join the programme provisionally, only if he/she submits a

certificate from the Principal/Registrar of his/her College/Institute stating that the candidate has

completed all the requirements for obtaining the bachelor&#39;s degree/equivalent qualification on the date

of the issue of the certificate. However, marks sheet of qualifying examination must be submitted to

the office of Dean (Academic) within six weeks from the last date of registration, failing which the

admission will be cancelled automatically.
</li><br />

<li>Applicants should note that the mere fulfilment of minimum eligibility criteria will not ensure

consideration for short listing by the Institute.
</li>
 <br />

<li> Applicants must have valid score of CAT -2016.</li>

<li><strong>
Note: This Institute uses CAT Percentile for short-listing the candidates for its full time two

years MBA programme. IIMs have no role either in the selection process or in the conduct of

the programme.</strong>
</li>
</ul>
</div>
</body>
</html>    