
<div id="main" style="font-size:13px; margin:0px 0 0 0;" align="justify">
			<p>
 <!--<center style="font-size:18px">
  List of provisionally selected candidates for admission to MBA programme
 </center>-->

<br/> 
<!--<p class="larger-font">Applications are invited for admission to MBA programme for session 2017-18 in the School

of Management Studies of the Institute. Eligible candidates may apply online through URL<strong>

http://academics.mnnit.ac.in/fresh_mba</strong> from 15.12.2016. After applying online, duly

filled-in and signed printed application form generated online must reach <strong>The Admission

Cell, Office of the Dean (Academic), MNNIT Allahabad, Allahabad – 211004</strong> latest by

07.2.2017 up to 5.30 PM along with the e-Receipt for fee payment of `1200.00 (`600.00 for

SC/ST). CAT 2016 scores shall be used for short-listing of candidates. IIMs have no role

either in the selection process or in the conduct of the programme.</p>-->

<!--<p class="larger-font"><h3>Last date for filling online applications is extended up to February 15, 2017. For other dates, Please refer "Important Dates".</p>-->



<h3><strong><a href="./data/Spot_Admission_MBA_2017_18.pdf">Declaration for Spot and final round of admission</a><br /><br /></h3></strong>

<h3><strong><a href="./data/Declaration of first round of admission_MBA_2017-18_For_uploading.pdf">Document related to declared of first round of admission [For getting information of total candidates shortlisted after GD and PI]</a><br /><br /></h3></strong>
<!--<h3>List of candidates who deposited fee in first round. Click <a href="./data/List_of_fee_deposit_in_I_Round_MBA_2017_18.pdf">here</a><br /><br /></h3>-->

</div>