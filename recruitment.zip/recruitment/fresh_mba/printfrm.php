<?php
session_start();
include_once('include/sql_func.php');
include_once('include/sql_functions.php');
include_once('include/misc_functions.php');
$connection=new sqlfunctions();
$connection->connect_db("mba_fresh");
if(!isset($_SESSION['logged']))
	redirect("index.php?val=allreg");
else
{
	
	$roll=$_SESSION['roll'];
	$due=get_dues($_SESSION['roll']);
	if($due['due']>0){
		palert("You have not paid your fees yet. Please pay your fee to print forms",'index.php');
		die();
	}
	$url=$_SERVER["PHP_SELF"];
	include_once('include/sql_func.php');
	include_once('include/sql_functions.php');
	include_once('include/misc_functions.php');
	$connection=new sqlfunctions();
	$err_connection=sql_connect_m();
	$connection->connect_db("mba_fresh");
	$query="SELECT `name`,`dob`,`fname`,`mname`,`pwd`,`cat`,`lpno`,`hpno`,`add`,`state`,`city`,`pin`,`nationality`,`sex`,`email`,`10board`,`10subject`,`10year`,`10mark`,`12board`,`12subject`,`12year`,`12mark`,`13board`,`13subject`,`13year`,`13mark`,`14board`,`14subject`,`14year`,`14mark`,`13val`,`14val`,`cat_per` FROM login as l,per_info as p, qualification as q WHERE l.roll=? and l.roll=p.roll and l.roll=q.roll ";
	if(!($res=$connection->prepare($query)))
	{
		log_error($err_connection,$url,$query,$res,1);
		$connection->close();
		redirect("error_page.html");
	}
	if(!($res->bind_param("s",$roll)))
	{
		log_error($err_connection,$url,$query,$res,2);
		$connection->close();
		redirect("error_page.html");
	}
	$roll=$_SESSION['roll'];
	if($res->execute())
	{
		$res->store_result();
		$res->bind_result($name,$dob,$fname,$mname,$pwd,$cat,$lpno,$hpno,$add,$state,$city,$pin,$nationality,$sex,$email,$x10board,$x10subject,$x10year,$x10mark,$x12board,$x12subject,$x12year,$x12mark,$x13board,$x13subject,$x13year,$x13mark,$x14board,$x14subject,$x14year,$x14mark,$x13val,$x14val,$score);
		$res->fetch();
	}
	else
	{	
		log_error($err_connection,$url,$query,$res,3);
		$connection->close();
		redirect("error_page.html");	
	}
	
	$sem = 0;
	$session=2017;
	$query="SELECT regno,sum(amount),GROUP_CONCAT(refno SEPARATOR ' | '),GROUP_CONCAT(`transaction_id` SEPARATOR ' | '),GROUP_CONCAT(`date_recv` SEPARATOR ' | ') FROM `fees`.`bank_detail` WHERE purpose like 'application' and sem='$sem' and `status` like 'success'  and session='$session' and regno=? GROUP BY regno";
	if(!($res3=$connection->prepare($query)))
	{
		log_error($err_connection,$url,$query,$res3,1);
		$connection->close();
		redirect("error_page.html");
	}
	if(!($res3->bind_param("s",$roll)))
	{
		log_error($err_connection,$url,$query,$res3,2);
		$connection->close();
		redirect("error_page.html");
	}
	if($res3->execute())
	{
		$res3->store_result();
		if($res3->num_rows==0)
		{
			$paid=0;
		}
		else
		{
			$res3->bind_result($x,$amount,$refno,$tranid,$dateoftran);
			$res3->fetch();
		}
		$connection->close();
	}
	
}

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Dean Academic Form</title>
<link rel="stylesheet" type="text/css" href="../include/bootstrap/css/bootstrap.min.css" >
<script src="../include/bootstrap/js/bootstrap.min.js"></script>
<link href="https://fonts.googleapis.com/css?family=Graduate|Roboto+Condensed|Yanone+Kaffeesatz" rel="stylesheet">
 <link rel="stylesheet" type="text/css" href="main.css" >
<style type="text/css">

.style1 {font-size: 16px}
</style>
<link href="styles.css" rel="stylesheet" type="text/css" />
<style type="text/css">

.style5 {font-size: 18px; font-weight: bold; }
.style51 {font-size: 16px; font-weight: bold; }
.style6 {
font-size: 18px;
font-weight: bold;
}
.style7 {font-size: 12px}
.style8 {font-size: 24px}
.style10 {color: #000000}
.style37 {font-size: 18px; font-weight: bold; color: #000000; }
label{
	display:inline-block;
	width:200px;
}
th{
	width:35%;
}
input[type=checkbox]{
	margin-right:10px;

}
.form
{
width:600px;
height:auto;
position:relative;
margin-right:auto;
margin-left:auto;
}
</style>


</head>

<body>
<div class="form">
<table width="100%" border="0">
<tr>
<td width="12%" height="87"><div align="center"><img src="logo-MNNIT.png" width="110" height="105" /></div></td>
<td width="73%"><h3 align="center" class="style5">MOTILAL NEHRU NATIONAL INSTITUTE OF TECHNOLOGY <br /> ALLAHABAD - 211004 (INDIA)<br />School of Management Studies<br /><div class="style51"><br>APPLICATION FORM FOR ADMISSION TO MBA PROGRAMME 2017-18
</div> </h3></td>
<td width="8%" class="right"><table width="100%" height="25%" border="1" cellpadding="0" cellspacing="0" bordercolor="#000000">

</tr>
</table></td>
</tr>
<tr>
<td colspan="3"><div align="center"><strong> </strong>
<strong>Roll No.</strong> <span class="style1"><?php echo $roll;?></span><br />
<hr style="margin:0"/>
</div></td>
</tr>
</table>


<div class="row">
<div class="col-md-8 col-xs-8">
<table class="table table-bordered table-striped">
<tr><th>Name of the Candidate:</th><td><?php echo $name;?></td></tr>
<tr><th>Date of Birth:</th><td><?php echo $dob;?></td></tr>
<tr><th>Nationality:</th><td><?php echo $nationality;?></td></tr>
<tr><th>Name of Father:</th><td><?php echo $fname;?></td></tr>
<tr><th>Name of Mother:</th><td><?php echo $mname;?></td></tr>
</table>
</div>
<div class="col-md-4 col-xs-4">
<table class="table">
<div align="center"><div style="margin-top:0px;margin-bottom:0px"><?php echo "<img src=./photos/".$_SESSION['roll'].".JPG style=\"margin-top:0px; border-width:thin;\" width=\"175\" height=\"180\" alt = \"Photo not in Records Please Upload Your Photo\" /> "; ?> </div>
<div align="center"><div style="margin-top:0px;margin-bottom:10px"><?php echo "<img src=./signature/".$_SESSION['roll'].".JPG style=\"margin-top:0px; border-width:thin;\" width=\"175\" height=\"50\" alt = \"Photo not in Records Please Upload Your Photo\"  />"; ?> </div>
</div></div>
</table>
</div>
</div>
<table class="table table-bordered table-striped">
<tr><th>Address for Correspondence:</th><td><?php echo $add;?></td><th style="width:10%">Sex:</th><td><?php $sex=strtolower($sex); if($sex=="m")echo " Male"; else echo " Female"; ?></td></tr>
<tr><th>State:</th><td><?php echo $state;?></td><th style="width:10%">Pin Code:</th><td><?php echo $pin;?></td></tr>
<tr><th>Email:</th><td><?php echo $email;?></td></tr>
<tr><th>Catagory:</th><td><?php echo strtoupper($cat);?></td><th style="width:20%">Physically Handicapped:</th><td><?php if($ph=="Y")echo "Yes";else echo "No";?></td></tr>
<tr><th>Phone No:</th><td><?php echo $lpno;?></td></tr>
<tr><th>Mobile No:</th><td><?php echo $hpno;?></td></tr>
<tr><th>CAT 2016 Percentile:</th><td><?php echo $score;?></td></tr>
<tr><th>MNNIT Reference No.:</th><td><?php echo $refno;?></td></tr> 	
<tr><th>Bank Transaction Id:</th><td><?php echo $tranid;?></td></tr> 
<tr><th>Date of Transaction.:</th><td><?php echo $dateoftran;?></td></tr> 
<tr><th>Amount:</th><td><?php echo " Rs ".$amount;?></td></tr>  
</table>

<hr />
<div style="page-break-before:always"></div>
<h4><strong>Academic Qualification :</strong></h4>
<table class="table acdqual table-bordered">
<tr><th>Examination</th><th>Board/University</th><th>Subjects</th><th>Year</th><th>Marks/Grade</th></tr>
<tr><th>High School or equivalent:</th><td><?php echo $x10board ?></td><td><?php echo $x10subject ?></td><td><?php echo $x10year ?></td><td><?php echo $x10mark ?> </td></tr>
<tr><th>Intermediate or equivalent:</th><td><?php echo $x12board ?></td><td><?php echo $x12subject ?></td><td><?php echo $x12year ?></td><td><?php echo $x12mark ?> </td></tr>
<tr><th>Graduation (Specify)<br /><?php echo $x13val ?></th><td><?php echo $x13board ?></td><td><?php echo $x13subject ?></td><td><?php echo $x13year ?></td><td><?php echo $x13mark ?> </td></tr>
<tr><th>Any other (Specify)<br /><?php echo $x14val ?></th><td><?php echo $x14board ?></td><td><?php echo $x14subject ?></td><td><?php echo $x14year ?></td><td><?php echo $x14mark ?> </td></tr>
</table>


<hr />
<h4><strong>List of documents Enclosed(Please enclose copy) : </strong></h4>
<div id="docu">
<p><input type="checkbox" name="doc" value="10" />High School Certificate</p>
<p><input type="checkbox" name="doc" value="mark" />Mark Sheet of Qualifying Exam</p>
<p><input type="checkbox" name="doc" value="cat" />CAT 2016 Score Card (If available)</p>
<p><input type="checkbox" name="doc" value="category" />Category Certificate(In format given in Downloads)</p>
<p><input type="checkbox" name="doc" value="character" />Character Certificate</p>
<p><input type="checkbox" name="doc" value="Migration" />Migration Certificate</p>
<p><input type="checkbox" name="doc" value="Migration" />Course Completion Certificate</p>
</div>
<hr />
 

<h4><strong>DECLARATION BY STUDENT</strong></h4>
<table class="table">
<tr>
<td height="41" colspan="4" >&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Certified that all information provided by me in this application form is correct to the best of my knowledge and belief and this application form is same as filled-in online.<br /> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;I understand that any wilful misrepresentation of facts will result in cancellation of my admission and dismissal from the Institute. If admitted, I shall abide by all the rules and regulations of the Institute.</td>
</tr>
<tr>
<td height="45" colspan="2" class="title02">Date _____________/____________/2017</td>
<td height="45" class="title02">&nbsp;</td>
<td height="45" class="title02"><div align="right"><br />
<br />
(Signature Of Student ) </div></td>
</tr>
</table>
<script> window.print(); </script>
</div> 
        