<?php
include_once('include/sql_func.php');
include_once('include/sql_functions.php');
include_once('include/misc_functions.php');
if(!isset($_SESSION['logged']))
	redirect("index.php?val=allreg");
else
{
	$url=$_SERVER["PHP_SELF"];
	include_once('include/sql_func.php');
	include_once('include/sql_functions.php');
	include_once('include/misc_functions.php');
	$connection=new sqlfunctions();
	$err_connection=sql_connect_m();
	$connection->connect_db("mba_fresh");
	$_POST=$connection->sanitize($_POST);
	$query="SELECT `name`,`dob`,`fname`,`mname`,`pwd`,`cat`,`lpno`,`hpno`,`add`,`state`,`city`,`pin`,`nationality`,`sex`,`email`,`10board`,`10subject`,`10year`,`10mark`,`12board`,`12subject`,`12year`,`12mark`,`13board`,`13subject`,`13year`,`13mark`,`14board`,`14subject`,`14year`,`14mark`,`13val`,`14val`,`cat_per` FROM login as l,per_info as p, qualification as q WHERE l.roll=? and l.roll=p.roll and l.roll=q.roll ";
	if(!($res=$connection->prepare($query)))
	{
		log_error($err_connection,$url,$query,$res,1);
		$connection->close();
		redirect("error_page.html");
	}
	if(!($res->bind_param("s",$roll)))
	{
		log_error($err_connection,$url,$query,$res,2);
		$connection->close();
		redirect("error_page.html");
	}
	$roll=$_SESSION['roll'];
	if($res->execute())
	{
		$res->store_result();
		$res->bind_result($name,$dob,$fname,$mname,$pwd,$cat,$lpno,$hpno,$add,$state,$city,$pin,$nationality,$sex,$email,$_10board,$_10subject,$_10year,$_10mark,$_12board,$_12subject,$_12year,$_12mark,$_13board,$_13subject,$_13year,$_13mark,$_14board,$_14subject,$_14year,$_14mark,$_13val,$_14val,$cat_per);
		$res->fetch();
		$connection->close();
	}
	else
	{	
		log_error($err_connection,$url,$query,$res,3);
		$connection->close();
		redirect("error_page.html");	
	}
}
?>
<script src="include/jquery2.3.1.js"></script>
<center><b style="font-size:18px;">Personal &amp; Academic Information</b></center>
<hr>
<p align="justify" class="larger-font"> 

<ul class="text-danger">
  <li> * Marked fields are mandatory.</li>
</ul>

</script>
<form class="form-horizontal" name="reg_frm" method="post" action="<?= $_SERVER['PHP_SELF'] ?>" >
<div class="tab-content">
      <div id="home" class="tab-pane fade in active">
        <h3>Personal Information</h3>
        <hr>
        <div class="form-group">
         	<label class="control-label col-sm-3" for="dob"><span class="text-danger">*</span> Gender :</label>  
          	<div class="col-sm-5">
          		<label class="radio-inline"><input type="radio" name="sex" required value="m" <?php if(isset($sex) && $sex=='m') echo 'checked';?> >Male</label>
                <label class="radio-inline"><input type="radio" name="sex" required value="f" <?php if(isset($sex) && $sex=='f') echo 'checked';?>>Female</label>
          	</div>
      	</div>
        <div class="form-group">
         	<label class="control-label col-sm-3" for="dob"><span class="text-danger">*</span> Category:</label>  
          	<div class="col-sm-5">
          		<label class="radio-inline"><input type="radio" name="cat" required value="OP" <?php if(isset($cat) && strcmp($cat,"OP")==0 ) {echo 'checked';}?> >Open</label>
                <label class="radio-inline"><input type="radio" name="cat" required value="OBC" <?php if(isset($cat) && $cat=='OBC') echo 'checked';?> >OBC</label>
                <label class="radio-inline"><input type="radio" name="cat" required value="SC" <?php if(isset($cat) && $cat=='SC') echo 'checked';?> >SC</label>
                <label class="radio-inline"><input type="radio" name="cat" required value="ST" <?php if(isset($cat) && $cat=='ST') echo 'checked';?> >ST</label>
          	</div>
      	</div>
        <div class="form-group">
         	<label class="control-label col-sm-3" for="dob"><span class="text-danger">*</span> Physically Handicapped:</label>
          	<div class="col-sm-5">
          		<label class="radio-inline"><input type="radio" required name="pwd" value="y" <?php if(isset($pwd) && $pwd=='y') echo 'checked';?> >Yes</label>
                <label class="radio-inline"><input type="radio" required name="pwd" value="n" <?php if(isset($pwd) && $pwd=='n') echo 'checked';?> >No</label>
          	</div>
      	</div>
        <div class="form-group">
        	<label class="control-label col-sm-3" for="email">Phone No.:</label>
        	<div class="col-sm-9">
         		<input type="text" class="form-control" placeholder="Enter your Personal Contact No." value="<?php if(isset($lpno)) echo "$lpno"; ?>" name="lpno" >
        	</div>
      	</div>
        <div class="form-group">
        	<label class="control-label col-sm-3" for="email"><span class="text-danger">*</span> Email:</label>
        	<div class="col-sm-9">
         		<input type="email" class="form-control" id="email" placeholder="Enter your Personal E-mail Address." value="<?php if(isset($email)) echo "$email"; ?>" name="email" required>
        	</div>
      	</div>
        <div class="form-group">
        	<label class="control-label col-sm-3" for="email"><span class="text-danger">*</span> Permanent Address:</label>
        	<div class="col-sm-9">
         		<input type="text" class="form-control" id="add" placeholder="Local address lines..." name="add" value="<?php if(isset($add)) echo "$add"; ?>" required>
        	</div>
      	</div>
        <div class="form-group">
        	<label class="control-label col-sm-3" for="email"><span class="text-danger">*</span> City:</label>
        	<div class="col-sm-3">
         		<input type="text" class="form-control" id="city" placeholder="City..." name="city" value="<?php if(isset($city)) echo "$city"; ?>" required>
        	</div>
            <label class="control-label col-sm-2" for="email"><span class="text-danger">*</span> State:</label>
        	<div class="col-sm-4">
         		<input type="text" class="form-control" id="state" placeholder="State..."  value="<?php if(isset($state)) echo "$state"; ?>" name="state" required>
        	</div>
      	</div>
        <div class="form-group">
        	<label class="control-label col-sm-3" for="email"><span class="text-danger">*</span> PIN:</label>
        	<div class="col-sm-3">
         		<input type="text" class="form-control" id="pin" placeholder="Enter Pincode" value="<?php if(isset($pin)) echo "$pin"; ?>" name="pin" required>
        	</div>
            <label class="control-label col-sm-2" for="email"><span class="text-danger">*</span> Nationality:</label>
        	<div class="col-sm-4">
         		<input type="text" class="form-control" id="nationality" placeholder="Nationality" name="nationality" value="<?php if(isset($nationality)) echo "$nationality"; ?>" required>
        	</div>
      	</div>
        <div class="form-group">
        	<label class="control-label col-sm-3" for="email"><span class="text-danger">*</span> Father's Name:</label>
        	<div class="col-sm-9">
         		<input type="text" class="form-control" id="fname" value="<?php if(isset($fname)) echo "$fname"; ?>" placeholder="Enter your father's name here..." name="fname" required>
        	</div>
      	</div>
        <div class="form-group">
        	<label class="control-label col-sm-3" for="email">Mother's Name:</label>
        	<div class="col-sm-9">
         		<input type="text" class="form-control" placeholder="Enter your mother's name here..." value="<?php if(isset($mname)) echo "$mname"; ?>" name="mname">
        	</div>
      	</div>
        <div class="form-group">
        	<label class="control-label col-sm-3" for="email">Contact No.:</label>
        	<div class="col-sm-9">
         		<input type="text" class="form-control" id="email" placeholder="Enter your alternate Contact No." value="<?php if(isset($hpno)) echo "$hpno"; ?>" name="hpno" required>
        	</div>
      	</div>
        <h3>Academic Information</h3>
        <hr>
        <div class="form-group">
    		<label class="control-label col-sm-3" for="email"><span class="text-danger">*</span> CAT Percentile:</label>
    		<div class="col-sm-9">
     			 <input type="text" class="form-control" id="cat_per" value="<?php if(isset($cat_per)) echo "$cat_per"; ?>" placeholder="Enter 0 if results haven't been declared yet." name="cat_per" required>
    		</div>
  		</div> 	
        <div class="form-group">
    		<label class="control-label col-sm-3" for="email"><span class="text-danger">*</span> High School Board:</label>
    		<div class="col-sm-9">
     			 <input type="text" class="form-control" id="a10board" value="<?php if(isset($_10board)) echo "$_10board"; ?>" placeholder="Board/University ..." name="10board" required>
    		</div>
  		</div> 
        <div class="form-group">
    		<label class="control-label col-sm-3" for="email" ><span class="text-danger">*</span> Subjects in High School:</label>
    		<div class="col-sm-9">
            	<textarea class="textarea form-control" required id="a10subject" placeholder="Subjects taken up during High school ..." name="10subject" ><?php if(isset($_10subject)) echo "$_10subject"; ?></textarea>
    		</div>
  		</div> 
        <div class="form-group">
    		<label class="control-label col-sm-3" for="email"><span class="text-danger">*</span> Year of Passing High School:</label>
    		<div class="col-sm-9">
     			 <input type="text" class="form-control" id="a10year"  value="<?php if(isset($_10year)) echo "$_10year"; ?>"   placeholder="Year of passing High school." name="10year" required>
    		</div>
  		</div> 	
        <div class="form-group">
    		<label class="control-label col-sm-3" for="email"><span class="text-danger">*</span> Marks/grade in High School:</label>
    		<div class="col-sm-9">
     			 <input type="text" class="form-control" id="a10mark" value="<?php if(isset($_10mark)) echo "$_10mark"; ?>"   placeholder="Mention the Grade/Percentage obtained in High School..." name="10mark" required>
    		</div>
  		</div>
        <div class="form-group">
    		<label class="control-label col-sm-3" for="email"><span class="text-danger">*</span> Intermediate Board:</label>
    		<div class="col-sm-9">
     			 <input type="text" class="form-control" id="a12board" placeholder="Board ..." value="<?php if(isset($_12board)) echo "$_12board"; ?>" name="12board" required>
    		</div>
  		</div> 
        <div class="form-group">
    		<label class="control-label col-sm-3" for="email" ><span class="text-danger">*</span> Subjects in Intermediate School:</label>
    		<div class="col-sm-9">
            	<textarea class="textarea form-control" required id="12subject" placeholder="Subjects taken up during Intermediate school ..."  name="12subject"><?php if(isset($_12subject)) echo "$_12subject"; ?></textarea>
    		</div>
  		</div> 
        <div class="form-group">
    		<label class="control-label col-sm-3" for="email"><span class="text-danger">*</span> Year of Passing Intermediate School:</label>
    		<div class="col-sm-9">
     			 <input type="text" class="form-control" id="a12year"  value="<?php if(isset($_12year)) echo "$_12year"; ?>" placeholder="Year of passing Intermediate school." name="12year" required>
    		</div>
  		</div> 	
        <div class="form-group">
    		<label class="control-label col-sm-3" for="email"><span class="text-danger">*</span> Marks/grade in Intermediate School:</label>
    		<div class="col-sm-9">
     			 <input type="text" class="form-control" id="a12mark"  value="<?php if(isset($_12mark)) echo "$_12mark"; ?>"  placeholder="Mention the Grade/Percentage obtained in Intermediate School..." name="12mark" required>
    		</div>
  		</div> 
        <div class="form-group">
    		<label class="control-label col-sm-3" for="email"><span class="text-danger">*</span> Graduate Degree Obtained :</label>
    		<div class="col-sm-9">
     			 <input type="text" class="form-control" id="a13val" placeholder="Degree Obtained ..."  value="<?php if(isset($_13val)) echo "$_13val"; ?>" name="13val" required>
    		</div>
  		</div> 
        <div class="form-group">
    		<label class="control-label col-sm-3" for="email"><span class="text-danger">*</span> Graduate School :</label>
    		<div class="col-sm-9">
     			 <input type="text" class="form-control" id="a13board" placeholder="Board/University ..." value="<?php if(isset($_13board)) echo "$_13board"; ?>" name="13board" required>
    		</div>
  		</div> 
        <div class="form-group">
    		<label class="control-label col-sm-3" for="email" ><span class="text-danger">*</span> Subjects taken during Graduate Study:</label>
    		<div class="col-sm-9">
            	<textarea class="textarea form-control" required id="a13subject" placeholder="Subjects taken up during Graduate school ..." name="13subject" ><?php if(isset($_13subject)) echo "$_13subject"; ?></textarea>
    		</div>
  		</div> 
        <div class="form-group">
    		<label class="control-label col-sm-3" for="email"><span class="text-danger">*</span> Year of Passing Graduate School:</label>
    		<div class="col-sm-9">
     			 <input type="text" class="form-control" id="a13year"  value="<?php if(isset($_13year)) echo "$_13year"; ?>" placeholder="Year of passing Graduate school." name="13year" required>
    		</div>
  		</div> 	
        <div class="form-group">
    		<label class="control-label col-sm-3" for="email"><span class="text-danger">*</span> Marks/grade in Graduate School:</label>
    		<div class="col-sm-9">
     			 <input type="text" class="form-control" id="a13mark"  value="<?php if(isset($_13mark)) echo "$_13mark"; ?>"  placeholder="Mention the Grade/Percentage/CPI obtained in Graduate School..." name="13mark" required>
    		</div>
  		</div> 	
        <h3>Additional Academic Information</h3>
        <hr>
        <div class="form-group">
    		<label class="control-label col-sm-3" for="email">Additional Degree Obtained :</label>
    		<div class="col-sm-9">
     			 <input type="text" class="form-control" placeholder="Degree Obtained ..." name="14val"  value="<?php if(isset($_14val)) echo "$_14val"; ?>"  >
    		</div>
  		</div> 
        <div class="form-group">
    		<label class="control-label col-sm-3" for="email">Additional School :</label>
    		<div class="col-sm-9">
     			 <input type="text" class="form-control"  placeholder="Board/University ..." value="<?php if(isset($_14board)) echo "$_14board"; ?>" name="14board" >
    		</div>
  		</div> 
        <div class="form-group">
    		<label class="control-label col-sm-3" for="email" >Subjects taken during extra Study:</label>
    		<div class="col-sm-9">
            	<textarea class="textarea form-control" placeholder="Subjects taken up during extra school ..." name="14subject"><?php if(isset($_14subject)) echo "$_14subject"; ?></textarea>
    		</div>
  		</div> 
        <div class="form-group">
    		<label class="control-label col-sm-3" for="email">Year of Passing the School:</label>
    		<div class="col-sm-9">
     			 <input type="text" class="form-control"  value="<?php if(isset($_14year)) echo "$_14year"; ?>"  placeholder="Year of passing the school." name="14year" >
    		</div>
  		</div> 	
        <div class="form-group">
    		<label class="control-label col-sm-3" for="email">Marks/grade in the School:</label>
    		<div class="col-sm-9">
     			 <input type="text" class="form-control"  value="<?php if(isset($_14mark)) echo "$_14mark"; ?>"  placeholder="Mention the Grade/Percentage/CPI obtained in the School..." name="14mark" >
    		</div>
  		</div> 	
  </div>
</div>
<div class="form-group"> 
    <div class="col-sm-offset-4 col-sm-4">
      <button type="submit" name="per_ch" class="btn btn-primary col-sm-12">Submit Information</button>
    </div>
  </div>
  </form>
</p>