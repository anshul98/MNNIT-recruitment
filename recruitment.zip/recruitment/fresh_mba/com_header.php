<div id="midtxtheading" style="margin-top:-3px;margin-bottom:12px;">
<div class="midboldtxt" style=" text-align:center;margin-top:-2px;">School of Management Studies<br />
Application to MBA programme for session 2017-18</div>
</div>