<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Intake</title>
<style>
.login {
	display:none;
}
#loginbox{
	display:none;
	text-align:center;
	margin:65px 7px -25px 5px;
	padding:25px 5px 15px 55px;
	background:#fff;
	color:#b22d00;
	-moz-border-radius:6px;
	-webkit-border-radius:6px;
}
.submit{
	height:20px;
	width:80px;
}
</style>
</head>

<body>
<div id="main" style="font-size:13px; margin:0px 0 0 0;" align="justify">
<center style="font-size:18px"><b>Total intake of students</b></center>
<hr />
<br />
<table class="table table-bordered larger-font" style="border-color:#23527c;"  align="center">
<tr>
<td style="border-color:#23527c;"><strong>OC</strong></td>
<td style="border-color:#23527c;"><strong>OCPH</strong></td>
<td style="border-color:#23527c;"><strong>OBC</strong></td>
<td style="border-color:#23527c;"><strong>OBCPH</strong></td>
<td style="border-color:#23527c;"><strong>SC</strong></td>
<td style="border-color:#23527c;"><strong>SCPH</strong></td>
<td style="border-color:#23527c;"><strong>ST</strong></td>
<td style="border-color:#23527c;"><strong>TOTAL</strong></td>
</tr>
<tr>
<td style="border-color:#23527c;">30</td>
<td style="border-color:#23527c;">1</td>
<td style="border-color:#23527c;">16</td>
<td style="border-color:#23527c;">1</td>
<td style="border-color:#23527c;">9</td>
<td style="border-color:#23527c;">0</td>
<td style="border-color:#23527c;">5</td>
<td style="border-color:#23527c;">62</td>
</tr>
</table>
</center>
<br />
<em><strong class="larger-font">Sub-Category reservation will be applicable as per Government of India rules. </strong></em>
</div>
</body>
</html>