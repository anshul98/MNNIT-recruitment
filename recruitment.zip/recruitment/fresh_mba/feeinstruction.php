<?php
include_once('include/sql_func.php');
include_once('include/sql_functions.php');
include_once('include/misc_functions.php');
if(!isset($_SESSION['logged']))
	redirect("index.php?val=allreg");
?>
<center><b style="font-size:18px;">Instructions for Fee Payment.</b></center>
<hr>
<strong>Steps:</strong>
<ul>
<li>Click on Next, only if you are ready to pay your FEES</li>
<li>Check All Your Details and then Click on "Pay" Button.
</li><li>You will be redirected on SBI MOPS page. Now, Select any of the payment mode and proceed further.
</li><li>Enter the Required details
</li><li>Pay the fees and after successful payment you will be shown Success Message.
</li><li>From the above successful page, now you have to return to Admission Portal by clicking on the link shown below or you will be redirected automatically after some time.
</li>
<li>
<strong>Last step is important otherwise transaction fee will not be  received by the Institute.
</strong></li>
</ul>
<br>
If you have already generated challan, click here to <a href="https://www.onlinesbi.com/prelogin/mopsremittanceform.htm" target="_blank">reprint</a> it.
<br><br>
If you are facing any other problem, then <a href="../support.php">Contact us</a>.
<br><br>

<button class='btn btn-primary' onClick="location.href='../admissionfee.php'" >NEXT </button>