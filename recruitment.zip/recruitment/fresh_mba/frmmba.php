    <style>
.style17 {
	color:#F00;
	
}
#part1{dispaly:block;}
#part2{display:none;}
</style>
<script type="text/javascript">
function func2(){
document.getElementById("part1").style.display="none";
document.getElementById("part2").style.display="block";	
document.getElementById("nex").style.visibility="hidden";
document.getElementById("pre").style.visibility="visible";
}
function func1(){
	document.getElementById("part1").style.display="block";
document.getElementById("part2").style.display="none";	
document.getElementById("nex").style.visibility="visible";
document.getElementById("pre").style.visibility="hidden";	
}
</script>
<?php 
$conn=mysql_connect("localhost","root","914passwd") or die(error1);
		mysql_select_db('mba_fresh',$conn) or die(dsf);
 require_once('recaptchalib.php');
  $publickey = "6LfCSNoSAAAAAPizTjv5HLo9__PnSpPKLf7elN9t"; // you got this from the signup page
  
if(isset($_SESSION['roll']))
{
	$roll=$_SESSION['roll'];
	$query="select * from per_info where roll=\"$roll\"";
	$res=mysql_query($query);
	if(mysql_num_rows($res)==0)
	{
		//	session_destroy();
	/*		echo "<script>window.location=\"./index.php\"</script>";
		die();
*/
	}
	$ans=mysql_fetch_array($res);
	$name=$ans['name'];
	$dob=$ans['dob'];
	$fname=$ans['fname'];
	$mname=$ans['mname'];
	$ph=$ans['ph'];
	$cat=$ans['cat'];
	$lpno=$ans['lpno'];
	$hpno=$ans['hpno'];
	$add=$ans['add'];
	$state=$ans['state'];
	$pin=$ans['pin'];
	$sex=$ans['sex'];
	
	$nationality=$ans['nationality'];
	$email=$ans['email'];
	$query="select score from score where roll=\"$roll\"";
	$ans=mysql_fetch_array(mysql_query($query));
	$score=$ans['score'];
	$query="select * from qualification where `roll`=\"$roll\"";
	$ans=mysql_fetch_array(mysql_query($query));
	$x10board=$ans['10board'];
	$x10subject=$ans['10subject'];
	$x10year=$ans['10year'];
	$x12board=$ans['12board'];
	$x12subject=$ans['12subject'];
	$x12year=$ans['12year'];
	$x13board=$ans['13board'];
	$x13subject=$ans['13subject'];
	$x13year=$ans['13year'];
	$x14board=$ans['14board'];
	$x14subject=$ans['14subject'];
	$x14year=$ans['14year'];
	$x10mark=$ans['10mark'];
	$x12mark=$ans['12mark'];
	$x13mark=$ans['13mark'];
	$x14mark=$ans['14mark'];
	$x14val=$ans['14val'];
	$x13val=$ans['13val'];	
}
else
{
	//session_destroy();
	/*echo "<script>window.location=\"./index.php\"</script>";
	die();
		*/
}
if(isset($_POST['submit']))
{$error=0;
$errmsg="";
//$roll=$_POST['roll'];
//$name=$_POST['name'];
$fname=$_POST['fname'];
$mname=$_POST['mname'];
$ph=$_POST['ph'];
$cat=$_POST['cat'];
$lpno=$_POST['lpno'];
$hpno=$_POST['hpno'];
$add=$_POST['add'];
$state=$_POST['state'];
$pin=$_POST['pin'];
$sex=$_POST['sex'];
$nationality=$_POST['nationality'];
$email=$_POST['email'];
//$dob=$_POST['dob'];
if(isset($_POST['score']))
{
	$score=$_POST['score'];
}

$x10board=$_POST['10board'];
$x10subject=$_POST['10subject'];
$x10year=$_POST['10year'];
$x12board=$_POST['12board'];
$x12subject=$_POST['12subject'];
$x12year=$_POST['12year'];
$x13board=$_POST['13board'];
$x13subject=$_POST['13subject'];
$x13year=$_POST['13year'];
$x14board=$_POST['14board'];
$x14subject=$_POST['14subject'];
$x14year=$_POST['14year'];
$x10mark=$_POST['10mark'];
$x12mark=$_POST['12mark'];
$x13mark=$_POST['13mark'];
$x14mark=$_POST['14mark'];
$x14val=$_POST['14val'];
$x13val=$_POST['13val'];
//$dob=$_POST['yr']."-".$_POST['mt']."-".$_POST['dt'];
//if($roll==""){$errmsg="roll can not be empty";$error++;}
if($name==""){$errmsg="Name can not be empty";$error++;}
if($fname==""){$errmsg="Father's name can not be empty";$error++;}
if($mname==""){$errmsg="MOther's name can not be empty";$error++;}
if($ph==""){$errmsg="Choose physically handicap yes or no";$error++;}
if($cat==""){$errmsg="Catagory can not be empty";$error++;}
if($lpno==""){$errmsg="Local phone no can not be empty";$error++;}
if($hpno==""){$errmsg="Home Phone No. can not be empty";$error++;}
if($add==""){$errmsg="Address can not be empty";$error++;}
if($state==""){$errmsg="State can not be empty";$error++;}
if($pin==""){$errmsg="Pincode can not be empty";$error++;}
if($sex==""){$errmsg="Sex can not be empty";$error++;}
if($nationality==""){$errmsg="Nationality can not be empty";$error++;}
if($email==""){$errmsg="Email can not be empty";$error++;}
if($dob==""){$errmsg="DOB can not be empty";$error++;}
if($score==""){$errmsg="Score can not be empty";$error++;}
if($score>100){$errmsg="Percentile should be <=100";$error++;}

if($x10board==""){$errmsg="10th board can not be empty";$error++;}
if($x10subject==""){$errmsg="10th subject can not be empty";$error++;}
if($x10year==""){$errmsg="10th year can not be empty";$error++;}
if($x12board==""){$errmsg="12th board can not be empty";$error++;}
if($x12subject==""){$errmsg="12th subject can not be empty";$error++;}
if($x12year==""){$errmsg="12th year can not be empty";$error++;}
if($x13board==""){$errmsg="Graduation board can not be empty";$error++;}
if($x13subject==""){$errmsg="Graduation subject can not be empty";$error++;}
if($x13year==""){$errmsg="Graduation year can not be empty";$error++;}
if($x10mark==""){$errmsg="10th mark can not be empty";$error++;}
if($x12mark==""){$errmsg="12th mark can not be empty";$error++;}
if($x13mark==""){$errmsg="Graduation mark can not be empty";$error++;}
if($x13val==""){$errmsg="Graduation field can not be empty";$error++;}
//if(mysql_num_rows(mysql_query("select * from mba_fresh.score where roll=\"$roll\""))>0)
//{$errmsg="Cat Roll No. Already registered Please Login to continue";$error++;
//}

/*---------------------not working umang,captcha not visible ---------------------------------------------------------------------------------
	require_once('recaptchalib.php');
  $privatekey = "6LfCSNoSAAAAAAB4X_wqGQP7WRxmAC477zwKgdoj";
  $resp = recaptcha_check_answer ($privatekey,
                                $_SERVER["REMOTE_ADDR"],
                                $_POST["recaptcha_challenge_field"],
                                $_POST["recaptcha_response_field"]);

  if (!$resp->is_valid) {
$errmsg="Captha Not Valid";
$error++;
		}
	else{
------------------------------------------------------------------------------------------------------------------------		*/
	
		//echo $error; //counting errors
		if($error<=0)
		{
/*------------ koi kaam ka nahin pehle ho chuka (at  step 1 registration )by umang------------------------------------------------
		$cdq="select code from code";
		//echo $cdq."sefgsdgg";
		$codar=mysql_fetch_array(mysql_query($cdq));
			$frmid="MBA-".$codar[0]."-2013";
			$cod=$codar[0]+1;
		//$cdq="update code set code=\"$cod\"";//1 step locha.
*/
		$querya="select * from score where roll=\"$roll\"";
		if(mysql_num_rows(mysql_query($querya))==0)
		{
			$query1="insert into score values (\"$roll\",\"$score\")";
		}
		else
		{
			$query1="update score set `score`=\"$score\" where roll=\"$roll\"";
		}
	//	$query2="insert into step values (\"$roll\",\"0\")";
		//$query3="insert into formid values (\"$roll\",\"$frmid\")";
		$query4="update per_info set fname=\"$fname\",mname=\"$mname\",ph=\"$ph\",cat=\"$cat\", lpno=\"$lpno\", hpno=\"$hpno\", `add`=\"$add\", state=\"$state\", pin=\"$pin\", sex=\"$sex\",nationality=\"$nationality\",email=\"$email\" where roll=\"$roll\"";
	//	$query4="insert into per_info values (\"$roll\",\"$name\",\"$fname\",\"$mname\",\"$ph\",\"$cat\",\"$lpno\",\"$hpno\",\"$add\",\"$state\",\"$pin\",\"$sex\",\"$nationality\",\"$email\",\"$dob\")";
		$query3="select * from qualification where roll=\"$roll\"";
		if(mysql_num_rows(mysql_query($query3))==0)
		{
		$query5="insert into qualification values (\"$roll\",\"$x10board\",\"$x10subject\",\"$x10year\",\"$x10mark\",\"$x12board\",\"$x12subject\",\"$x12year\",\"$x12mark\",\"$x13val\",\"$x13board\",\"$x13subject\",\"$x13year\",\"$x13mark\",\"$x14val\",\"$x14board\",\"$x14subject\",\"$x14year\",\"$x14mark\")";
		}
		else
		{
			$query5="update qualification set `10board`=\"$x10board\",`10subject`=\"$x10subject\", `10year`=\"$x10year\", `10mark`=\"$x10mark\", `12board`=\"$x12board\", `12subject`=\"$x12subject\", `12year`=\"$x12year\", `12mark`=\"$x12mark\", `13val`=\"$x13val\", `13board`=\"$x13board\", `13subject`=\"$x13subject\", `13year`=\"$x13year\", `13mark`=\"$x13mark\", `14val`=\"$x14val\", `14board`=\"$x14board\", `14subject`=\"$x14subject\", `14year`=\"$x14year\",`14mark`=\"$x14mark\" where roll=\"$roll\"";
		}
		
		mysql_query($query4) or die(error5);
		mysql_query($query5) or die(error4);
		mysql_query($query1) or die(error6);
		//mysql_query($query5) or die(error6);
		$_SESSION['roll']=$roll;
/*----------------------------------changed by umang----------------------------------------------------------		
		echo "<script>window.location=\"./printfrm.php\"</script>";
*/echo "<script>window.location=\"./home.php\"</script>";
		die();
		}
		
		
	/*----------------------}--- bracket of else part in capctha verification -----------------------------------*/
}
?>
<table border="0" cellspacing="0" cellpadding="0" width="100%" height="100%">
                
              <tr valign="top"> 
                <td colspan="2" >
        <!----------         
				  <?php
				  if(count($errors)>0 || $done=="yes")
{
	?>
    <script type="text/javascript">
	$('#errors').slideDown('slow');
	</script>
    <?php 
}
				  ?>-------->
                 
				  <?php $xl=0; ?>
                  <form name="form1" method="post" action="./home.php?val=nuser"><!--<?php// echo $_SERVER['PHP_SELF'];?>">-->
                  <table width="100%" border="0" align="center" style="z-index:99">
				    
                    <tr>
                      <td colspan="4">
                    	
                         <?php if($error>0) {?>
                <div class="error-style"> <font color="#FF0000"><center> <?php echo "**".$errmsg; ?> </center></font></div><?php }?>
                        <div align="right" class="error-style"><font color="#FF0000">*</font> Marked Are Mandatory <br />
</div>
						<br /><br /><br /> 
						</td>
					</tr>
                   
			   <tr>
                      <td height="20" class="style16"><?php echo ++$xl.")";  ?></td>
                      <td class="title01">CAT 2015 Roll No: <span class="style17">*</span></td>
                      <td><input name="roll" type="text" id="ph_no"<?php echo "value=\"$roll\"" ?> disabled />					  </td>
                       </tr>
                        <tr>
                      <td height="55" class="style16"><?php echo ++$xl.")";  ?></td>
                      <td class="title02">CAT 2015 Percentile: <span class="style17">*</span></td>
                      <td><input name="score" type="text"  <?php if(isset($score)) echo "value=\"$score\"" ?> /><p align="left"	><font size='-2'>Enter 0 (zero) if result is not yet declared.</font></p>				  </td>
                       </tr>
                       </table>
                  <br />
                   <div id="part1"> 
                    <fieldset>
                    <legend>Personal Details</legend>
                    <table width="100%" border="0" align="center">
                      
                        
                    <tr>
                      <td width="3%" class="style16"><?php echo ++$xl.")";  ?></td>
                      <td width="57%" class="title02">Name <span class="style17">*</span> </td>
                      <td width="38%"><input name="name" type="text" id="name" size="27" <?php if(isset($name)) echo "value=\"$name\"" ?> disabled></td>
                    </tr>
                    <tr>
                      <td class="style16"><?php echo ++$xl.")";  ?></td>
                      <td class="title02">Date Of Birth <span class="style17">*</span> </td>
                      <td><div align="left">
                        
             <select name="dt" id="dt" disabled>
			
				<?php

        			$date = substr( "$dob",8,2);
        			for( $i=1;$i<=31;$i++) 
					{
                		if ( $i < 10 ) 
						{
                        	if( $date == $i ) 
							{ 
								echo "<option value=0".$i." selected>0".$i."</option>"; 
							}
                        	else 
							{ echo "<option value=0".$i.">0".$i."</option>"; }
                		}
                		else
                		{
						 	if( $date == $i ) 
							{ 
								echo "<option value=".$i." selected>".$i."</option>"; 
							}
                        else 
							{  echo "<option value=".$i.">".$i."</option>"; }
                		}
        			}
			
			 	$mon=substr("$dob",5,2);
				?>
            </select>
		
			 
				<?php //$mon=$_POST['mt'] ?>
              <select name="mt" id="mt" disabled>
				<option value="01" selected  <?php  if ( $mon == 1 ){ echo "selected"; } ?>>Jan</option>
				<option value="02"  <?php  if ( $mon == 2 ){ echo "selected"; } ?> >Feb</option>
				<option value="03"  <?php  if ( $mon == 3 ){ echo "selected"; } ?> >Mar</option>
				<option value="04"  <?php   if ( $mon == 4 ){ echo "selected"; } ?> >Apr</option>
				<option value="05"   <?php   if ( $mon == 5 ){ echo "selected"; } ?>>May</option>
				<option value="06"   <?php   if ( $mon == 6 ){ echo "selected"; } ?>>Jun</option>
				<option value="07"   <?php   if ( $mon == 7 ){ echo "selected"; } ?>>July</option>
				<option value="08"   <?php   if ( $mon == 8 ){ echo "selected"; } ?>>Aug</option>
				<option value="09"   <?php   if ( $mon == 9 ){ echo "selected"; } ?>>Sep</option>
				<option value="10"   <?php   if ( $mon == 10 ){ echo "selected"; } ?>>Oct</option>
				<option value="11"   <?php   if ( $mon == 11 ){ echo "selected"; } ?>>Nov</option>
				<option value="12"   <?php   if ( $mon == 12 ){ echo "selected"; } ?>>Dec</option>
		      </select>
			  
              <select name="yr" id="yr" disabled>
				<?php
				$year=substr("$dob",0,4);
				for( $i=1970;$i<=1996;$i++) 
				{
					if( $year == $i ) 
						{ echo "<option value=".$i." selected>".$i."</option>"; }
					else { echo "<option value=".$i.">".$i."</option>"; }
				}
				?>
              </select>           
                      
                      </div></td>
                    </tr>
                    
                    <tr>
                      <td class="style16"><?php echo ++$xl.")";  ?></td>
                      <td class="title02">Sex <span class="style17">*</span></td>
                      <td>
                        <input name="sex" type="radio" value="M" <?php if(isset($sex)&&$sex == "M") echo "checked"; ?> >
                        MALE
                        <input name="sex" type="radio" value="F" <?php if(isset($sex)&&$sex == "F") echo "checked"; ?> >
                        FEMALE                      </td>
                    </tr>
                    <!----------<tr>
                      <td class="style16"><?php echo ++$xl.")";  ?></td>
                      <td class="title02">Blood Group <span class="style17">*</span></td>
                      <td><select name="blood_gp" id="blood_gp">
                        <option value="A+" <?php if($blood_gp == "A+") echo 'selected';?>>A+</option>
                        <option value="A-" <?php if($blood_gp == "A-") echo 'selected';?>>A-</option>
                        <option value="B+" <?php if($blood_gp == "B+") echo 'selected';?>>B+</option>
                        <option value="B-" <?php if($blood_gp == "B-") echo 'selected';?>>B-</option>
                        <option value="AB+" <?php if($blood_gp == "AB+") echo 'selected';?>>AB+</option>
                        <option value="AB-" <?php if($blood_gp == "AB-") echo 'selected';?>>AB-</option>
                        <option value="O+" <?php if($blood_gp == "O+") echo 'selected';?>>O+</option>
                        <option value="O-" <?php if($blood_gp == "O-") echo 'selected';?>>O-</option>
                      </select>                      </td>
                    </tr>-------------->
                   
                    <tr>
                     <tr>
                     
                      <td class="style16"><?php echo ++$xl.")";  ?></td>
                      <td class="title02">Category <span class="style17">*</span></td>
                      <td>
                   <select name="cat">
    <option value="op" <?php if(isset($cat)&&$cat=="op") echo 'selected' ?>>OPEN</option>
    <option value="sc" <?php if(isset($cat)&&$cat=="sc") echo 'selected' ?>>SC</option>
    <option value="st" <?php if(isset($cat)&&$cat=="st") echo 'selected' ?>>ST</option>
    <option value="obc" <?php if(isset($cat)&&$cat=="obc") echo 'selected' ?>>OBC</option>
    
   
  </select>
  </td>
  
                    <tr>
                      <td class="style16"><?php echo ++$xl.")";  ?></td>
                      <td class="title02">Physically Handicapped<span class="style17">*</span></td>
                      <td>
                        <input name="ph" type="radio" value="Y" <?php if(isset($ph)&&$ph == "Y") echo "checked";  ?>>
                       Yes
                        <input name="ph" type="radio" value="N" <?php if(isset($ph)&&$ph == "N") echo "checked";  ?>>
                       No                      </td>
                    </tr>
                    
                    </tr>
                   
                    <tr>
                      <td class="style16"><?php echo ++$xl.")";  ?></td>
                      <td class="title02">Phone No.<span class="style17">*</span></td>
                      <td><input name="lpno" type="text" id="ph_no" size="27" 
					   <?php if(isset($lpno)) echo "value=\"$lpno\"" ?>  />
					  </td>
                    </tr>
                   <tr>
                      <td height="55" class="style16"><?php echo ++$xl.")";  ?></td>
                      <td class="title02">Permanent Address <span class="style17">*</span></td>
                      <td><textarea name="add" rows="4" id="p_address"><?php if(isset($add)) echo $add ?></textarea>					  </td>
                       </tr>
                        <tr>
                      <td height="55" class="style16"><?php echo ++$xl.")";  ?></td>
                      <td class="title02">State <span class="style17">*</span></td>
                      <td> <select name="state" id="ph_no">
                    
                      <option value="Andhra Pradesh" <?php if(isset($state)&&$state=="Andhra Pradesh") echo "selected"; ?> >Andhra Pradesh</option>
<option value="Arunachal Pradesh" <?php if(isset($state)&&$state=="Arunachal Pradesh") echo "selected"; ?>	>Arunachal Pradesh</option>
<option value="Assam" <?php if(isset($state)&&$state=="Assam") echo "selected"; ?>	>Assam</option>
<option value="Bihar" <?php if(isset($state) &&$state=="Bihar") echo "selected"; ?>	>Bihar</option>
<option value="Chandigarh" <?php if(isset($state)&&$state=="Chandigarh") echo "selected"; ?>	>Chandigarh</option>
<option value="Chhattisgarh"<?php if(isset($state)&&$state=="Chhattisgarh") echo "selected"; ?>	>Chhattisgarh</option>
<option value="Dadra and Nagar Haveli"<?php if(isset($state)&&$state=="Dadra and Nagar Haveli") echo "selected"; ?>	>Dadra and Nagar Haveli</option>
<option value="Daman and Diu"<?php if(isset($state)&&$state=="Daman and Diu") echo "selected"; ?>	>Daman and Diu</option>
<option value="Delhi"<?php if(isset($state)&&$state=="Delhi") echo "selected"; ?>	>Delhi</option>
<option value="Goa"<?php if(isset($state)&&$state=="Goa") echo "selected"; ?>	>Goa</option>
<option value="Gujarat"<?php if(isset($state)&&$state=="Gujarat") echo "selected"; ?>	>Gujarat</option>
<option value="Haryana"<?php if(isset($state)&&$state=="Haryana") echo "selected"; ?>	>Haryana</option>
<option value="Himachal Pradesh"<?php if(isset($state)&&$state=="Himachal Pradesh") echo "selected"; ?>	>Himachal Pradesh</option>
<option value="Jammu and Kashmir"<?php if(isset($state)&&$state=="Jammu and Kashmir") echo "selected"; ?>	>Jammu and Kashmir</option>
<option value="Jharkhand"<?php if(isset($state)&&$state=="Jharkhand") echo "selected"; ?>	>Jharkhand</option>
<option value="Karnataka"<?php if(isset($state)&&$state=="Karnataka") echo "selected"; ?>	>Karnataka</option>
<option value="Kerala"<?php if(isset($state)&&$state=="Kerala") echo "selected"; ?>	>Kerala</option>
<option value="Lakshadweep"<?php if(isset($state)&&$state=="Lakshadweep") echo "selected"; ?>	>Lakshadweep</option>
<option value="Madhya Pradesh"<?php if(isset($state)&&$state=="Madhya Pradesh") echo "selected"; ?>	>Madhya Pradesh</option>
<option value="Maharashtra"<?php if(isset($state)&&$state=="Maharashtra") echo "selected"; ?>	>Maharashtra</option>
<option value="Manipur"<?php if(isset($state)&&$state=="Manipur") echo "selected"; ?>	>Manipur</option>
<option value="Meghalaya"<?php if(isset($state)&&$state=="Meghalaya") echo "selected"; ?>	>Meghalaya</option>
<option value="Mizoram"<?php if(isset($state)&&$state=="Mizoram") echo "selected"; ?>	>Mizoram</option>
<option value="Nagaland"<?php if(isset($state)&&$state=="Nagaland") echo "selected"; ?>	>Nagaland</option>
<option value="Orissa"<?php if(isset($state)&&$state=="Orissa") echo "selected"; ?>	>Orissa</option>
<option value="Pondicherry"<?php if(isset($state)&&$state=="Pondicherry") echo "selected"; ?>	>Pondicherry</option>
<option value="Punjab"<?php if(isset($state)&&$state=="Punjab") echo "selected"; ?>	>Punjab</option>
<option value="Rajasthan"<?php if(isset($state)&&$state=="Rajasthan") echo "selected"; ?>	>Rajasthan</option>
<option value="Sikkim"<?php if(isset($state)&&$state=="Sikkim") echo "selected"; ?>	>Sikkim</option>
<option value="Tamil Nadu"<?php if(isset($state)&&$state=="Tamil Nadu") echo "selected"; ?>	>Tamil Nadu</option>
<option value="Telangana"<?php if(isset($state)&&$state=="Telangana") echo "selected"; ?>	>Telangana</option>
<option value="Tripura"<?php if(isset($state)&&$state=="Tripura") echo "selected"; ?>	>Tripura</option>
<option value="Uttaranchal"<?php if(isset($state)&&$state=="Uttaranchal") echo "selected"; ?>	>Uttaranchal</option>
<option value="Uttar Pradesh"<?php if(isset($state)&&$state=="Uttar Pradesh") echo "selected"; ?>	>Uttar Pradesh</option>
<option value="West Bengal"<?php if(isset($state)&&$state=="West Bengal") echo "selected"; ?>	>West Bengal</option>

                      
                      <?php if(isset($state)) echo "value=\"$state\"" ?>			</select>  </td>
                       </tr>
                        <tr>
                      <td height="55" class="style16"><?php echo ++$xl.")";  ?></td>
                      <td class="title02">Pin Code: <span class="style17">*</span></td>
                      <td><input name="pin" type="text" id="ph_no" size="27" <?php if(isset($pin)) echo "value=\"$pin\"" ?> />					  </td>
                       </tr>
                        <tr>
                      <td height="55" class="style16"><?php echo ++$xl.")";  ?></td>
                      <td class="title02">Nationality: <span class="style17">*</span></td>
                      <td><input name="nationality" type="text" id="ph_no" size="27" <?php if(isset($nationality)) echo "value=\"$nationality\"" ?> />					  </td>
                       </tr>
                    
                    
					<tr>
                      <td class="style16"><?php echo ++$xl.")";  ?></td>
                      <td class="title02">Mother's Name<span class="style17">*</span></td>
                      <td><input name="mname" type="text" id="m_name" size="27"
					 <?php if(isset($mname)) echo "value=\"$mname\"" ?>
					   ></td>
                      </tr>
                    <tr>
                      <td class="style16"><?php echo ++$xl.")";  ?></td>
                      <td class="title02">Father's Name <span class="style17">*</span></td>
                      <td><input name="fname" type="text" id="fname" size="27" 
					  <?php if(isset($fname)) echo "value=\"$fname\"" ?>
					  ></td>
                     </tr>
                    
                     
                    <tr>
                      <td class="style16"><?php echo ++$xl.")";  ?></td>
                      <td class="title02">Mobile No.<span class="style17">*</span></td>
                      <td><input name="hpno" type="text" id="f_ph_no" size="27"
					 
					  	
					  <?php if(isset($hpno)) echo "value=\"$hpno\"" ?>
					  	
					 
					  ></td>
                     </tr>
                    <tr>
                      <td class="style16"><?php echo ++$xl.")";  ?></td>
                      <td class="title02">Email Address<span class="style17">*</span></td>
                      <td><input name="email" type="email" id="email" size="27"
					  <?php if(isset($email)) echo "value=\"$email\"" ?>
					   ></td>
                     </tr><tr></tr><tr></tr>
                    </table>
                   
                  </fieldset>
                   <br /></div> <div id="part2"><br />
                    <fieldset>
                    <legend>Academic Qualification</legend>
                    <table width="100%" border="0" align="center">
					
                   <tr>
                      <td height="55" class="style16"><?php echo ++$xl.")";  ?></td>
                      <td class="title02">High School Organization:<span class="style17">*</span></td>
                      <td><textarea name="10board" rows="2" id="p_address"><?php if(isset($x10board)) echo $x10board ?></textarea>					  </td>
                       </tr>
                       <tr>
                      <td height="55" class="style16"><?php echo ++$xl.")";  ?></td>
                      <td class="title02">Subjects in High School: <span class="style17">*</span></td>
                      <td><textarea name="10subject" rows="2" id="p_address"><?php if(isset($x10subject)) echo $x10subject ?></textarea>					  </td>
                       </tr>
                         <tr>
                      <td  class="style16"><?php echo ++$xl.")";  ?></td>
                      <td class="title02">Year of Passing High School:<span class="style17">*</span></td>
                      <td><input type="text" name="10year" id="m_name" size="27"<?php if(isset($x10year)) echo "value=\"$x10year\""; ?>				 />  </td>
                       </tr>
                         <tr>
                      <td  class="style16"><?php echo ++$xl.")";  ?></td>
                      <td class="title02">Marks/grade in High School:<span class="style17">*</span></td>
                      <td><input type="text" name="10mark"  id="m_name" size="27" <?php if(isset($x10mark)) echo "value=\"$x10mark\"" ?>	 /><br />				  </td>
                       </tr> 
                   
                    <tr> <td><hr /></td><td><hr /></td><td><hr /></td></tr>
                     
                       <tr>
                      <td height="55" class="style16"><?php echo ++$xl.")";  ?></td>
                      <td class="title02">Intermediate Organization:<span class="style17">*</span></td>
                      <td><textarea name="12board" rows="2" id="p_address"><?php if(isset($x12board)) echo $x12board ?></textarea>					  </td>
                       </tr>
                       <tr>
                      <td height="55" class="style16"><?php echo ++$xl.")";  ?></td>
                      <td class="title02">Intermediate Subjects:<span class="style17">*</span></td>
                      <td><textarea name="12subject" rows="2" id="p_address"><?php if(isset($x12subject)) echo $x12subject ?></textarea>					  </td>
                       </tr>
                         <tr>
                      <td  class="style16"><?php echo ++$xl.")";  ?></td>
                      <td class="title02">Year of Passing:<span class="style17">*</span></td>
                      <td><input type="text" name="12year" id="m_name" size="27" <?php if(isset($x12year)) echo "value=\"$x12year\"" ?> />		  </td>
                       </tr>
                         <tr>
                      <td class="style16"><?php echo ++$xl.")";  ?></td>
                      <td class="title02">Marks/Grade:<span class="style17">*</span></td>
                      <td><input type="text" name="12mark"  id="m_name" size="27" <?php if(isset($x12mark)) echo "value=\"$x12mark\"" ?> />  </td>
                       </tr>
                       <tr> <td><hr /></td><td><hr /></td><td><hr /></td></tr>
                        <tr>
                      <td class="style16"><?php echo ++$xl.")";  ?></td>
                      <td class="title02">Graduation(Specify) <span class="style17">*</span></td>
                      <td><input type="text" name="13val"  id="m_name" size="27"  <?php if(isset($x13val)) echo "value=\"$x13val\"" ?>>	  </td>
                       </tr>
                       <tr>
                      <td height="55" class="style16"><?php echo ++$xl.")";  ?></td>
                      <td class="title02">Graduation Board/University <span class="style17">*</span></td>
                      <td><textarea name="13board" rows="2" id="p_address" ><?php if(isset($x13board)) echo $x13board ?></textarea>					  </td>
                       </tr>
                       <tr>
                      <td height="55" class="style16"><?php echo ++$xl.")";  ?></td>
                      <td class="title02">Graduation Subjects <span class="style17">*</span></td>
                      <td><textarea name="13subject" rows="2" id="p_address"><?php if(isset($x13subject)) echo $x13subject; ?></textarea>					  </td>
                       </tr>
                         <tr>
                      <td  class="style16"><?php echo ++$xl.")";  ?></td>
                      <td class="title02">Graduation year <span class="style17">*</span></td>
                      <td><input type="text" name="13year" id="m_name" size="27"  <?php if(isset($x13subject)) echo "value=\"$x13year\"" ?>  />			  </td>
                       </tr>
                         <tr>
                      <td class="style16"><?php echo ++$xl.")";  ?></td>
                      <td class="title02">Graduation marks/grade <span class="style17">*</span></td>
                      <td><input type="text" name="13mark"  id="m_name" size="27"  <?php if(isset($x13year)) echo "value=\"$x13mark\"" ?>/> </td>
                       </tr>
                    <tr> <td><hr /></td><td><hr /></td><td><hr /></td></tr>
                     <tr>
                      <td class="style16"><?php echo ++$xl.")";  ?></td>
                      <td class="title02">Any Other(Specify) </td>
                      <td><input type="text" name="14val"  id="m_name" size="27"   <?php if(isset($x14val)) echo "value=\"$x14val\"" ?>/>  </td>
                       </tr>
                       <tr>
                      <td height="55" class="style16"><?php echo ++$xl.")";  ?></td>
                      <td class="title02">Any Other Board/University</td>
                      <td><textarea name="14board" rows="2" id="p_address" ><?php if(isset($x14board)) echo $x14board ?></textarea>					  </td>
                       </tr>
                       <tr>
                      <td height="55" class="style16"><?php echo ++$xl.")";  ?></td>
                      <td class="title02">Any Other Subjects </td>
                      <td><textarea name="14subject" rows="2" id="p_address" ><?php if(isset($x14subject)) echo $x14subject ?> </textarea>					  </td>
                       </tr>
                         <tr>
                      <td  class="style16"><?php echo ++$xl.")";  ?></td>
                      <td class="title02">Any Other year </td>
                      <td><input type="text" name="14year" id="m_name" size="27" <?php if(isset($x14year)) echo "value=\"$x14year\"" ?>/>	  </td>
                       </tr>
                         <tr>
                      <td class="style16"><?php echo ++$xl.")";  ?></td>
                      <td class="title02">Any Other marks/grade </td>
                      <td><input type="text" name="14mark"  id="m_name" size="27"   <?php if(isset($x14mark)) echo "value=\"$x14mark\"" ?>/>	  </td>
                       </tr>
                      </table>                 
                  </fieldset>
                   <br />	<br />
                  
                    <table width="100%" border="0" align="center">
                 <!----------------------captcha not working---------------------------------------------------
                   <tr><td colspan="3"> <center><?php echo recaptcha_get_html($publickey);?></center>
                   <br /></td></tr>
                 --->
                    <tr>
                      <td colspan="4" align="center" ><input type="submit" class="button" value="Submit" name="submit"></td>
                    </tr>
                  </table>
                 </div>
                 
                  </form>
                  
                   <table width="100%" border="0" align="center">
                  <tr>
                  <td align="left" ><input type="button" class="button" value="Previous" id="pre" onclick="func1()" style="visibility:hidden;"></td>
                  <td align="right" ><input type="button" class="button" value="Next" id="nex" onclick="func2()" ></td>
                  </tr>
                  </table>
                  
                  </td>
              </tr>
</table>

    