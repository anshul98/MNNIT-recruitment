<?php

//echo 111111;
				//echo $_FILES['sign']['name'];
				//echo $_FILES['sign']['tmp_name'];
				$targetDir="./signature";
				$imageName=stripslashes($_FILES['sign']['name']);
				//echo $imageName;
				//echo $misc->Extension($imageName);
				$extension=$misc->Extension($imageName);
				if(!$extension)
				{
					;
				}
				else if (($extension != "JPG") &&($extension != "jpg"))
				{
					$errorInUploading++;
					$misc->palert("The Extension of your file was ".$extension.". Only JPG Files are allowed!","");
				}
				else if(filesize($_FILES['sign']['tmp_name'])>20*1024)
				{
					$errorInUploading++;
					$misc->palert("File exceeds 20KB size Limit !!",""); 
				}
				else if($errorInUploading==0)
				{
					$imageName=$_SESSION['roll'].'.'."JPG";
					$newName=$targetDir."/".$imageName;
					exec("chmod 777 ".$newName);
					if (file_exists($newName))
					unlink($newName);
					//echo $newName;
					//echo $_FILES['sign']['tmp_name'];
					$copied = move_uploaded_file($_FILES['sign']['tmp_name'], $newName);
					//$misc->palert($newName,"");
					if (!$copied) 
					{ 
							$errorInUploading=1;  				
							$misc->palert("Copy unsuccessfull!","");
					}
				}
				?>