
    <!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
    <html xmlns="http://www.w3.org/1999/xhtml">
    <head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Dean Academics, MNNIT Allahabad</title>
    <script src="include/jquery-2.1.4.min.js"></script>
    
    <!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
    
	<!-- Latest compiled and minified JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>
    <link rel="icon" href="images/MNNIT1.ico" />
    <link href="https://fonts.googleapis.com/css?family=Graduate|Roboto+Condensed|Yanone+Kaffeesatz" rel="stylesheet">

    <link rel="stylesheet" type="text/css" href="include/lv-ripple.css">
	<link rel="stylesheet" type="text/css" href="include/style.css">
    </head>
   
    <body style="overflow-x:hidden;">
    <link rel="stylesheet" type="text/css" href="main.css" >
       
        <div id="headerbg" class="col-md-12" style="padding:1%"> 
         	<div class="col-md-2 col-xs-4 col-xs-offset-4" style="margin-left:40px;width:150px">
            	<img class="img-responsive" src="logo-MNNIT.png" style="height:150px">
            </div>
            <div class="col-md-9">
            <center><h3 style="color:white;font-family: 'Graduate', cursive;margin-left:50px; line-height:30px;">MOTILAL NEHRU NATIONAL INSTITUTE OF TECHNOLOGY<br />ALLAHABAD<br /><br />Office of The Dean (Academic)</h3></center>
            </div>
        </div>
        
        
    
    <div class="container-fluid" style="padding-top:10px">
        <div class="col-xs-offset-2 col-xs-8 col-md-offset-0 col-md-3" style="margin-top:3%">
            <div class="panel panel-primary">
                <div class="panel panel-heading" style="border-bottom-left-radius:0; border-bottom-right-radius:0; margin-bottom:0px;">
                        <h4 align="center">
                        	Contents
                        </h4>
                </div>
                <div class="panel panel-body" style="padding:0px; margin:0px;">
                	<div class="well" style="margin:0px;">
                        <div class="list-group">           	
                            <a class="list-group-item <?php if(!isset($_GET['val']) ) echo "active"; ?> " name="profile" href="./index.php" >Home</a>
                            <a class="list-group-item <?php if(isset($_GET['val']) && $_GET['val']=='elb' ) echo "active"; ?> " name="profile" href="./index.php?val=elb" >Eligiblity</a>
                            <a class="list-group-item <?php if(isset($_GET['val']) && $_GET['val']=='intake' ) echo "active"; ?>" id="midframe" href="./index.php?val=intake">Intake</a>
                            <a class="list-group-item <?php if(isset($_GET['val']) && $_GET['val']=='res' ) echo "active"; ?>" id="midframe" href="./index.php?val=res">Reservation</a>
                            <a class="list-group-item <?php if(isset($_GET['val']) && $_GET['val']=='app' ) echo "active"; ?>" id="midframe" href="./index.php?val=app">Application Procedure</a>
                            <a class="list-group-item <?php if(isset($_GET['val']) && $_GET['val']=='sul' ) echo "active"; ?>" id="midframe" href="./index.php?val=sul">Selection Procedure</a>
                            <a class="list-group-item <?php if(isset($_GET['val']) && $_GET['val']=='date' ) echo "active"; ?>" id="midframe" href="./index.php?val=date">Important Dates</a>
                            <a class="list-group-item <?php if(isset($_GET['val']) && $_GET['val']=='contact' ) echo "active"; ?>" id="midframe" href="./index.php?val=contact">Contacts</a>
                            <a class="list-group-item <?php if(isset($_GET['val']) && $_GET['val']=='refund' ) echo "active"; ?>" id="midframe" href="./index.php?val=refund">Refund Policy</a>
                            <a class="list-group-item <?php if(isset($_GET['val']) && $_GET['val']=='dis' ) echo "active"; ?>" id="midframe" href="./index.php?val=dis">Disclaimer</a>
                            <a class="list-group-item <?php if(isset($_GET['val']) && $_GET['val']=='download' ) echo "active"; ?> " id="midframe" href="./index.php?val=download">Performas and Download</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-xs-offset-0 col-xs-12 col-md-offset-0 col-md-6" style="margin-top:3%">
            <div class="panel panel-default" style="border:0px">
                <div class="panel panel-heading" style="background:#012B5D">
                        <h3 align="center" class="text-info" style="font-family: 'Yanone Kaffeesatz', sans-serif;font-size:26px;color:#fff;margin-top:10px">
                        	School of Management Studies<br />
							Application to <strong>M.B.A</strong> programme for session <strong>2017-18</strong>
                        </h3>
                </div>
                <div class="panel panel-body" style="padding:0px;">
                	<div class="well">
                        <div class="list-group">
                             <?php 
        					if($_GET['val']=="nuser")
                             	include("register.php");  
							else  if($_GET['val']=="allreg")
								include("login.php");
							else  if($_GET['val']=="download")
								include("download.php");
							else  if($_GET['val']=="elb")
								include("eligiblity.php");
							else  if($_GET['val']=="intake")
								include("intake.php");
							else  if($_GET['val']=="res")
								include("reservation.php");
							else  if($_GET['val']=="app")
								include("app.php");
							else  if($_GET['val']=="sul")
								include("sul.php");
							else  if($_GET['val']=="date")
								include("dates.php");
							else  if($_GET['val']=="contact")
								include("contact.php");
							else  if($_GET['val']=="refund")
								include("refund.php");
							else if($_GET['val']=="dis")
								include("disclaimer.php");
							else if($_GET['val']=="impnotice")
								echo "<img src='./data/imp.jpg' width='500px'>";
							else if($_GET['val']=="basicinfo")	
								include("basicinfo.php");
							else if($_GET['val']=="perinfo")	
								include("perinfo.php");
							else if($_GET['val']=="feeinst")	
								include("pay.php");
							else if($_GET['val']=="photo")	
								include("upload_photo.php");
							else
								include("./select.php");  
							
           	   				?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-xs-offset-2 col-xs-8 col-md-offset-0 col-md-3" style="margin-top:3%">
            <div class="panel panel-primary">
                <div class="panel panel-heading" style="border-bottom-left-radius:0; border-bottom-right-radius:0; margin-bottom:0px;">
                        <h4 align="center">
                        	Important Links
                        </h4>
                </div>
                <div class="panel panel-body" style="padding:0px; margin:0px;">
                	<div class="well" style="margin:0px;">
                    	<?php
								if(isset($_SESSION['logged']))
								{
						?>
                                    <p align="center" style="margin-bottom:5px;">Logged in with CAT Roll No. : <br /> <strong style="font-size:18px;"><?= $_SESSION['roll'] ?></strong></p>
                                    <hr style="margin-top:0px;"/>
                        <?php
								}
						?>
                                
                        <div class="list-group">
                        	<?php
								if(isset($_SESSION['logged']) )
								{
									?>
                                    <a class="list-group-item list-group-item-danger" id="midframe" href="./logout.php">LogOut <span class="glyphicon glyphicon-off"></span></a>
                                    <?php
								}
								else
								{
									?>
                                    <a class="list-group-item <?php if(isset($_GET['val']) && $_GET['val']=='allreg' ) echo "active"; else echo "list-group-item-info"; ?> " id="midframe" href="./index.php?val=allreg"><strong>Login</strong></a>
                                    <?php
								}
							?>
                            <a class="list-group-item <?php if(isset($_GET['val']) && $_GET['val']=='nuser' ) { echo "active"; } else if(isset($_SESSION['logged'])) { echo "disabled";} ?> " id="midframe" href="<?php if(isset($_SESSION['logged'])) { echo "";} else {echo "./index.php?val=nuser";} ?>"><strong>Register</strong></a>
                        </div>  
                        <?php
							if(isset($_SESSION['logged']))
							{
								//$due=get_dues($_SESSION['roll']);           it was generating error 
						?>
                        		
                        	    <p align="center" style="margin-bottom:5px;">Registration Steps<br /></p>
                                <hr style="margin-top:0px;"/>
                                <div class="list-group">
                                	<a class="list-group-item <?php if(isset($_GET['val']) && $_GET['val']=='basicinfo' ) echo "active"; ?> " id="midframe" href="./index.php?val=basicinfo"><strong>1. Basic Information</strong></a>
                                    <a class="list-group-item <?php if(isset($_GET['val']) && $_GET['val']=='perinfo' ) echo "active"; ?> " id="midframe" href="./index.php?val=perinfo"><strong>2. Personal Information</strong></a>
                                    <a class="list-group-item <?php if(isset($_GET['val']) && $_GET['val']=='photo' ) echo "active"; ?> " id="midframe" href="./index.php?val=photo"><strong>3. Upload Photographs</strong></a>
                                    <a class="list-group-item <?php if(isset($_GET['val']) && $_GET['val']=='feeinst' ) echo "active"; ?> " id="midframe" href="./index.php?val=feeinst"><strong>4. Pay Fees</strong></a>
                                    <a class="list-group-item <?php if($due['due']>0){echo "disabled";}else if(isset($_GET['val']) && $_GET['val']=='print' ) echo "active"; ?> " id="midframe" href="<?php if($due['due']>0){echo "#";}else{echo "printfrm.php\" target=\"_blank\"";}?>"  ><strong>5. Print Forms</strong></a>

                                </div>
                        <?php
							}
						?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <footer class="well" style="margin:0px; padding:10px;margin-top:12px;">
         <p class="small" style="margin-bottom:0px;" align="center">&copy; Webteam, Dean Academics <br />
                MNNIT Allahabad.<br />
				This is a &beta; version and is under devleopment.
         </p>
     </footer>
     <script type="text/javascript" src="include/lv-ripple.jquery.js"></script>
	<script type="text/javascript" src="include/app.js"></script>
    </body>
    </html>
                                                   