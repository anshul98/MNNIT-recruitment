<?php
die("Registration closed");
session_start();
require_once ('../included_classes/class_sql.php');
require_once ('../included_classes/class_user.php');
require_once ('../included_classes/class_misc.php');
if(!isset($_SESSION['roll']))
{echo "<script>window.location=\"./index.php\"</script>";
		die();
		}
$error=0;
$conn=mysql_connect("localhost","root","nowbanned") or die(error1);
		mysql_select_db('mba_fresh',$conn) or die(dsf);
$arrp=mysql_fetch_array(mysql_query("select * from per_info where roll=\"$_SESSION[roll]\""));
$arrx=mysql_fetch_array(mysql_query("select * from qualification where roll=\"$_SESSION[roll]\""));
$sc=mysql_fetch_array(mysql_query("select * from score where roll=\"$_SESSION[roll]\""));
$roll=$arrp['roll'];
$name=$arrp['name'];
$fname=$arrp['fname'];
$mname=$arrp['mname'];
$ph=$arrp['ph'];
$cat=$arrp['cat'];
$score=$sc['score'];
$lpno=$arrp['lpno'];
$hpno=$arrp['hpno'];
$add=$arrp['add'];
$state=$arrp['state'];
$pin=$arrp['pin'];
$sex=$arrp['sex'];
$nationality=$arrp['nationality'];
$email=$arrp['email'];
$dob=$arrp['dob'];
$x10board=$arrx['10board'];
$x10subject=$arrx['10subject'];
$x10year=$arrx['10year'];
$x12board=$arrx['12board'];
$x12subject=$arrx['12subject'];
$x12year=$arrx['12year'];
$x13board=$arrx['13board'];
$x13subject=$arrx['13subject'];
$x13year=$arrx['13year'];
$x14board=$arrx['14board'];
$x14subject=$arrx['14subject'];
$x14year=$arrx['14year'];
$x10mark=$arrx['10mark'];
$x12mark=$arrx['12mark'];
$x13mark=$arrx['13mark'];
$x14mark=$arrx['14mark'];
$x14val=$arrx['14val'];
$x13val=$arrx['13val'];
if(isset($_POST['submit']))
{$error=0;
$errmsg="";
$roll=$_SESSION['roll'];
$name=$_POST['name'];
$fname=$_POST['fname'];
$mname=$_POST['mname'];
$ph=$_POST['ph'];
$cat=$_POST['cat'];
$lpno=$_POST['lpno'];
$hpno=$_POST['hpno'];
$add=$_POST['add'];
$state=$_POST['state'];
$pin=$_POST['pin'];
$sex=$_POST['sex'];
$nationality=$_POST['nationality'];
$email=$_POST['email'];
$dob=$_POST['dob'];
$score=$_POST['score'];
$x10board=$_POST['10board'];
$x10subject=$_POST['10subject'];
$x10year=$_POST['10year'];
$x12board=$_POST['12board'];
$x12subject=$_POST['12subject'];
$x12year=$_POST['12year'];
$x13board=$_POST['13board'];
$x13subject=$_POST['13subject'];
$x13year=$_POST['13year'];
$x14board=$_POST['14board'];
$x14subject=$_POST['14subject'];
$x14year=$_POST['14year'];
$x10mark=$_POST['10mark'];
$x12mark=$_POST['12mark'];
$x13mark=$_POST['13mark'];
$x14mark=$_POST['14mark'];
$x14val=$_POST['14val'];
$x13val=$_POST['13val'];
$dob=$_POST['yr']."-".$_POST['mt']."-".$_POST['dt'];
if($roll==""){$errmsg="roll can not be empty";$error++;}
if($name==""){$errmsg="name can not be empty";$error++;}
if($fname==""){$errmsg="fname can not be empty";$error++;}
if($mname==""){$errmsg="mname can not be empty";$error++;}
if($ph==""){$errmsg="choose physically handicap yes or no";$error++;}
if($cat==""){$errmsg="catagory can not be empty";$error++;}
if($lpno==""){$errmsg="local phone no can not be empty";$error++;}
if($hpno==""){$errmsg="hpno can not be empty";$error++;}
if($add==""){$errmsg="address can not be empty";$error++;}
if($state==""){$errmsg="state can not be empty";$error++;}
if($pin==""){$errmsg="pincode can not be empty";$error++;}
if($sex==""){$errmsg="sex can not be empty";$error++;}
if($nationality==""){$errmsg="nationality can not be empty";$error++;}
if($email==""){$errmsg="email can not be empty";$error++;}
if($dob==""){$errmsg="dob can not be empty";$error++;}
if($score==""){$errmsg="score can not be empty";$error++;}
if($x10board==""){$errmsg="10th board can not be empty";$error++;}
if($x10subject==""){$errmsg="10th subject can not be empty";$error++;}
if($x10year==""){$errmsg="10th year can not be empty";$error++;}
if($x12board==""){$errmsg="12th board can not be empty";$error++;}
if($x12subject==""){$errmsg="12th subject can not be empty";$error++;}
if($x12year==""){$errmsg="12th year can not be empty";$error++;}
if($x13board==""){$errmsg="Graduation board can not be empty";$error++;}
if($x13subject==""){$errmsg="Graduation subject can not be empty";$error++;}
if($x13year==""){$errmsg="Graduation year can not be empty";$error++;}
if($x10mark==""){$errmsg="10th mark can not be empty";$error++;}
if($x12mark==""){$errmsg="12th mark can not be empty";$error++;}
if($x13mark==""){$errmsg="Graduation mark can not be empty";$error++;}
if($x13val==""){$errmsg="Graduation field can not be empty";$error++;}


	

 {
	//	echo $error;
		if($error<=0)
		{
			
		$query1="update score set score=\"$score\" where roll=\"$roll\"";
		$query3="delete from per_info where roll=\"$roll\"";
		$query2="delete from  qualification where roll=\"$roll\"";
		$query4="insert into per_info values (\"$roll\",\"$name\",\"$fname\",\"$mname\",\"$ph\",\"$cat\",\"$lpno\",\"$hpno\",\"$add\",\"$state\",\"$pin\",\"$sex\",\"$nationality\",\"$email\",\"$dob\")";
		$query5="insert into qualification values (\"$roll\",\"$x10board\",\"$x10subject\",\"$x10year\",\"$x10mark\",\"$x12board\",\"$x12subject\",\"$x12year\",\"$x12mark\",\"$x13val\",\"$x13board\",\"$x13subject\",\"$x13year\",\"$x13mark\",\"$x14val\",\"$x14board\",\"$x14subject\",\"$x14year\",\"$x14mark\")";
		mysql_query($query1) or die(error3);
		mysql_query($query2) or die(error3);
		mysql_query($query3) or die(error4);
		mysql_query($query4) or die(error5);
		mysql_query($query5) or die(error6);
		echo "<script>alert(\"updated\")</script><script>window.location=\"./home.php\"</script>";
		die();
		}
		
		
	}
}
?>


<table border="0" cellspacing="0" cellpadding="0" width="100%" height="100%">
                
              <tr valign="top"> 
                <td colspan="2" >
        <!----------         
				  <?php
				  if(count($errors)>0 || $done=="yes")
{
	?>
    <script type="text/javascript">
	$('#errors').slideDown('slow');
	</script>
    <?php 
}
				  ?>-------->
                 
				  <?php $xl=0; ?>
                  <form name="form1" method="post" action="">
                  <table width="100%" border="0" align="center">
				    
                    <tr>
                      <td colspan="4">
                    	
                        <br />
                         <?php if($error>0) {?>
                <div class="error-style"> <font color="#FF0000"><center> <?php echo "**".$errmsg; ?> </center></font></div><?php }?>
                        <div align="right" class="error-style"><font color="#FF0000">*</font> Marked Are Mandatory </div>
						<br />
						</td>
					</tr>
			 <tr>
                      <td height="20" class="style16"><?php echo ++$xl.")";  ?></td>
                      <td class="title01">CAT 2012 Roll No: <span class="style17">*</span></td>
                      <td><input name="roll" type="text" id="ph_no"<?php if(isset($roll)) echo "value=\"$roll\"" ?> disabled="disabled" />					  </td>
                       </tr>
                        <tr>
                      <td height="55" class="style16"><?php echo ++$xl.")";  ?></td>
                      <td class="title02">CAT 2012 Score(percentile): <span class="style17">*</span></td>
                      <td><input name="score" type="text" id="ph_no" <?php if(isset($score)) echo "value=\"$score\"" ?>   />					  </td>
                       </tr>
                    <tr>
                      <td width="3%" class="style16"><?php echo ++$xl.")";  ?></td>
                      <td width="57%" class="title02">Your Name <span class="style17">*</span> </td>
                      <td width="38%"><input name="name" type="text" id="name" size="27" <?php if(isset($name)) echo "value=\"$name\"" ?> ></td>
                    </tr>
                    <tr>
                      <td class="style16"><?php echo ++$xl.")";  ?></td>
                      <td class="title02">Date Of Birth <span class="style17">*</span> </td>
                      <td><div align="left">
                        
             <select name="dt" id="dt">
			
				<?php

        			$date = substr( "$dob",8,2);
        			for( $i=1;$i<=31;$i++) 
					{
                		if ( $i < 10 ) 
						{
                        	if( $date == $i ) 
							{ 
								echo "<option value=0".$i." selected>0".$i."</option>"; 
							}
                        	else 
							{ echo "<option value=0".$i.">0".$i."</option>"; }
                		}
                		else
                		{
						 	if( $date == $i ) 
							{ 
								echo "<option value=".$i." selected>".$i."</option>"; 
							}
                        else 
							{  echo "<option value=".$i.">".$i."</option>"; }
                		}
        			}
			
			 	$mon=substr("$dob",5,2);
				?>
            </select>
		
			 
				<?php //$mon=$_POST['mt'] ?>
              <select name="mt" id="mt">
				<option value="01" selected  <?  if ( $mon == 1 ){ echo "selected"; } ?>>Jan</option>
				<option value="02"  <?  if ( $mon == 2 ){ echo "selected"; } ?> >Feb</option>
				<option value="03"  <?  if ( $mon == 3 ){ echo "selected"; } ?> >Mar</option>
				<option value="04"  <?  if ( $mon == 4 ){ echo "selected"; } ?> >Apr</option>
				<option value="05"   <?  if ( $mon == 5 ){ echo "selected"; } ?>>May</option>
				<option value="06"   <?  if ( $mon == 6 ){ echo "selected"; } ?>>Jun</option>
				<option value="07"   <?  if ( $mon == 7 ){ echo "selected"; } ?>>July</option>
				<option value="08"   <?  if ( $mon == 8 ){ echo "selected"; } ?>>Aug</option>
				<option value="09"   <?  if ( $mon == 9 ){ echo "selected"; } ?>>Sep</option>
				<option value="10"   <?  if ( $mon == 10 ){ echo "selected"; } ?>>Oct</option>
				<option value="11"   <?  if ( $mon == 11 ){ echo "selected"; } ?>>Nov</option>
				<option value="12"   <?  if ( $mon == 12 ){ echo "selected"; } ?>>Dec</option>
		      </select>
			  
              <select name="yr" id="yr">
				<?php
				$year=substr("$dob",0,4);
				for( $i=1970;$i<=1996;$i++) 
				{
					if( $year == $i ) 
						{ echo "<option value=".$i." selected>".$i."</option>"; }
					else { echo "<option value=".$i.">".$i."</option>"; }
				}
				?>
              </select>           
                      
                      </div></td>
                    </tr>
                   
                    <tr>
                      <td class="style16"><?php echo ++$xl.")";  ?></td>
                      <td class="title02">Sex <span class="style17">*</span></td>
                      <td>
                        <input name="sex" type="radio" value="M" <? if($sex == "M") echo "checked"; ?>>
                        MALE
                        <input name="sex" type="radio" value="F" <? if($sex == "F") echo "checked"; ?>>
                        FEMALE                      </td>
                    </tr>
                    <!----------<tr>
                      <td class="style16"><?php echo ++$xl.")";  ?></td>
                      <td class="title02">Blood Group <span class="style17">*</span></td>
                      <td><select name="blood_gp" id="blood_gp">
                        <option value="A+" <?php if($blood_gp == "A+") echo 'selected';?>>A+</option>
                        <option value="A-" <?php if($blood_gp == "A-") echo 'selected';?>>A-</option>
                        <option value="B+" <?php if($blood_gp == "B+") echo 'selected';?>>B+</option>
                        <option value="B-" <?php if($blood_gp == "B-") echo 'selected';?>>B-</option>
                        <option value="AB+" <?php if($blood_gp == "AB+") echo 'selected';?>>AB+</option>
                        <option value="AB-" <?php if($blood_gp == "AB-") echo 'selected';?>>AB-</option>
                        <option value="O+" <?php if($blood_gp == "O+") echo 'selected';?>>O+</option>
                        <option value="O-" <?php if($blood_gp == "O-") echo 'selected';?>>O-</option>
                      </select>                      </td>
                    </tr>-------------->
                   
                    <tr>
                     <tr>
                     
                      <td class="style16"><?php echo ++$xl.")";  ?></td>
                      <td class="title02">Catagory <span class="style17">*</span></td>
                      <td>
                   <select name="cat">
    <option value="op" <?php if(isset($cat)&&$cat=="op") echo 'selected' ?>>OPEN</option>
    <option value="sc" <?php if(isset($cat)&&$cat=="sc") echo 'selected' ?>>SC</option>
    <option value="st" <?php if(isset($cat)&&$cat=="st") echo 'selected' ?>>ST</option>
    <option value="obc" <?php if(isset($cat)&&$cat=="obc") echo 'selected' ?>>OBC</option>
    
   
  </select>
  </td>
  
                    <tr>
                      <td class="style16"><?php echo ++$xl.")";  ?></td>
                      <td class="title02">Physically Handicapped<span class="style17">*</span></td>
                      <td>
                        <input name="ph" type="radio" value="Y" <? if(isset($ph)&&$ph == "Y") echo "checked";  ?>>
                       Yes
                        <input name="ph" type="radio" value="N" <? if(isset($ph)&&$ph == "N") echo "checked";  ?>>
                       No                      </td>
                    </tr>
                    
                    </tr>
                   
                    <tr>
                      <td class="style16"><?php echo ++$xl.")";  ?></td>
                      <td class="title02">Local Phone No.</td>
                      <td><input name="lpno" type="text" id="ph_no" size="27" 
					   <?php if(isset($lpno)) echo "value=\"$lpno\"" ?>  />
					  </td>
                    </tr>
                   <tr>
                      <td height="55" class="style16"><?php echo ++$xl.")";  ?></td>
                      <td class="title02">Permanent Address <span class="style17">*</span></td>
                      <td><textarea name="add" rows="4" id="p_address"><?php if(isset($add)) echo $add ?></textarea>					  </td>
                       </tr>
                        <tr>
                      <td height="55" class="style16"><?php echo ++$xl.")";  ?></td>
                      <td class="title02">State <span class="style17">*</span></td>
                      <td><input name="state" type="text" id="ph_no" size="27" <?php if(isset($state)) echo "value=\"$state\"" ?>  />				  </td>
                       </tr>
                        <tr>
                      <td height="55" class="style16"><?php echo ++$xl.")";  ?></td>
                      <td class="title02">Pin Code: <span class="style17">*</span></td>
                      <td><input name="pin" type="text" id="ph_no" size="27" <?php if(isset($pin)) echo "value=\"$pin\"" ?> />					  </td>
                       </tr>
                        <tr>
                      <td height="55" class="style16"><?php echo ++$xl.")";  ?></td>
                      <td class="title02">Nationality: <span class="style17">*</span></td>
                      <td><input name="nationality" type="text" id="ph_no" size="27" <?php if(isset($nationality)) echo "value=\"$nationality\"" ?> />					  </td>
                       </tr>
                    
                    
					<tr>
                      <td class="style16"><?php echo ++$xl.")";  ?></td>
                      <td class="title02">Mother's Name<span class="style17">*</span></td>
                      <td><input name="mname" type="text" id="m_name" size="27"
					 <?php if(isset($mname)) echo "value=\"$mname\"" ?>
					   ></td>
                      </tr>
                    <tr>
                      <td class="style16"><?php echo ++$xl.")";  ?></td>
                      <td class="title02">Father's Name <span class="style17">*</span></td>
                      <td><input name="fname" type="text" id="fname" size="27" 
					  <?php if(isset($fname)) echo "value=\"$fname\"" ?>
					  ></td>
                     </tr>
                    
                     
                    <tr>
                      <td class="style16"><?php echo ++$xl.")";  ?></td>
                      <td class="title02">Home Phone No.</td>
                      <td><input name="hpno" type="text" id="f_ph_no" size="27"
					 
					  	
					  <?php if(isset($hpno)) echo "value=\"$hpno\"" ?>
					  	
					 
					  ></td>
                     </tr>
                    <tr>
                      <td class="style16"><?php echo ++$xl.")";  ?></td>
                      <td class="title02"> Your Email Address<span class="style17">*</span></td>
                      <td><input name="email" type="text" id="email" size="27"
					  <?php if(isset($email)) echo "value=\"$email\"" ?>
					   ></td>
                     </tr><tr></tr><tr></tr>
					<br />	<br />
					<tr>
						<td colspan="3" align="center">
						<br />
						<b><u>Academic Qualification:</u></b>
						<br />
						</td>
					</tr>
					<br />	
                   <tr>
                      <td height="55" class="style16"><?php echo ++$xl.")";  ?></td>
                      <td class="title02">10th Board/University <span class="style17">*</span></td>
                      <td><textarea name="10board" rows="2" id="p_address"><?php if(isset($x10board)) echo $x10board ?></textarea>					  </td>
                       </tr>
                       <tr>
                      <td height="55" class="style16"><?php echo ++$xl.")";  ?></td>
                      <td class="title02">10th Subjects <span class="style17">*</span></td>
                      <td><textarea name="10subject" rows="2" id="p_address"><?php if(isset($x10subject)) echo $x10subject ?></textarea>					  </td>
                       </tr>
                         <tr>
                      <td  class="style16"><?php echo ++$xl.")";  ?></td>
                      <td class="title02">10th year <span class="style17">*</span></td>
                      <td><input type="text" name="10year" id="m_name" size="27"<?php if(isset($x10year)) echo "value=\"$x10year\""; ?>				 />  </td>
                       </tr>
                         <tr>
                      <td  class="style16"><?php echo ++$xl.")";  ?></td>
                      <td class="title02">10th marks/grade <span class="style17">*</span></td>
                      <td><input type="text" name="10mark"  id="m_name" size="27" <?php if(isset($x10mark)) echo "value=\"$x10mark\"" ?>	 /><br />				  </td>
                       </tr> 
                   
                    <tr> <td><hr /></td><td><hr /></td><td><hr /></td></tr>
                     
                       <tr>
                      <td height="55" class="style16"><?php echo ++$xl.")";  ?></td>
                      <td class="title02">12th Board/University <span class="style17">*</span></td>
                      <td><textarea name="12board" rows="2" id="p_address"><?php if(isset($x12board)) echo $x12board ?></textarea>					  </td>
                       </tr>
                       <tr>
                      <td height="55" class="style16"><?php echo ++$xl.")";  ?></td>
                      <td class="title02">12th Subjects <span class="style17">*</span></td>
                      <td><textarea name="12subject" rows="2" id="p_address"><?php if(isset($x12subject)) echo $x12subject ?></textarea>					  </td>
                       </tr>
                         <tr>
                      <td  class="style16"><?php echo ++$xl.")";  ?></td>
                      <td class="title02">12th year <span class="style17">*</span></td>
                      <td><input type="text" name="12year" id="m_name" size="27" <?php if(isset($x12year)) echo "value=\"$x12year\"" ?> />		  </td>
                       </tr>
                         <tr>
                      <td class="style16"><?php echo ++$xl.")";  ?></td>
                      <td class="title02">12th marks/grade <span class="style17">*</span></td>
                      <td><input type="text" name="12mark"  id="m_name" size="27" <?php if(isset($x12mark)) echo "value=\"$x12mark\"" ?> />  </td>
                       </tr>
                       <tr> <td><hr /></td><td><hr /></td><td><hr /></td></tr>
                        <tr>
                      <td class="style16"><?php echo ++$xl.")";  ?></td>
                      <td class="title02">Graduation(Specify) <span class="style17">*</span></td>
                      <td><input type="text" name="13val"  id="m_name" size="27"  <?php if(isset($x13val)) echo "value=\"$x13val\"" ?>>	  </td>
                       </tr>
                       <tr>
                      <td height="55" class="style16"><?php echo ++$xl.")";  ?></td>
                      <td class="title02">Graduation Board/University <span class="style17">*</span></td>
                      <td><textarea name="13board" rows="2" id="p_address" ><?php if(isset($x13board)) echo $x13board ?></textarea>					  </td>
                       </tr>
                       <tr>
                      <td height="55" class="style16"><?php echo ++$xl.")";  ?></td>
                      <td class="title02">Graduation Subjects <span class="style17">*</span></td>
                      <td><textarea name="13subject" rows="2" id="p_address"><?php if(isset($x13subject)) echo $x13subject; ?></textarea>					  </td>
                       </tr>
                         <tr>
                      <td  class="style16"><?php echo ++$xl.")";  ?></td>
                      <td class="title02">Graduation year <span class="style17">*</span></td>
                      <td><input type="text" name="13year" id="m_name" size="27"  <?php if(isset($x13subject)) echo "value=\"$x13year\"" ?>  />			  </td>
                       </tr>
                         <tr>
                      <td class="style16"><?php echo ++$xl.")";  ?></td>
                      <td class="title02">Graduation marks/grade <span class="style17">*</span></td>
                      <td><input type="text" name="13mark"  id="m_name" size="27"  <?php if(isset($x13year)) echo "value=\"$x13mark\"" ?>/> </td>
                       </tr>
                    <tr> <td><hr /></td><td><hr /></td><td><hr /></td></tr>
                     <tr>
                      <td class="style16"><?php echo ++$xl.")";  ?></td>
                      <td class="title02">Any Other(Specify) </td>
                      <td><input type="text" name="14val"  id="m_name" size="27"   <?php if(isset($x14val)) echo "value=\"$x14val\"" ?>/>  </td>
                       </tr>
                       <tr>
                      <td height="55" class="style16"><?php echo ++$xl.")";  ?></td>
                      <td class="title02">Any Other Board/University</td>
                      <td><textarea name="14board" rows="2" id="p_address" ><?php if(isset($x14board)) echo $x14board ?></textarea>					  </td>
                       </tr>
                       <tr>
                      <td height="55" class="style16"><?php echo ++$xl.")";  ?></td>
                      <td class="title02">Any Other Subjects </td>
                      <td><textarea name="14subject" rows="2" id="p_address" ><?php if(isset($x14subject)) echo $x14subject ?> </textarea>					  </td>
                       </tr>
                         <tr>
                      <td  class="style16"><?php echo ++$xl.")";  ?></td>
                      <td class="title02">Any Other year </td>
                      <td><input type="text" name="14year" id="m_name" size="27" <?php if(isset($x14year)) echo "value=\"$x14year\"" ?>/>	  </td>
                       </tr>
                         <tr>
                      <td class="style16"><?php echo ++$xl.")";  ?></td>
                      <td class="title02">Any Other marks/grade </td>
                      <td><input type="text" name="14mark"  id="m_name" size="27"   <?php if(isset($x14mark)) echo "value=\"$x14mark\"" ?>/>	  </td>
                       </tr>
                       <tr> <td><hr /></td><td><hr /></td><td><hr /></td></tr>
                   
                    <tr>
                      <td colspan="4" align="center" ><input type="submit" class="button" value="Submit" name="submit"></td>
                    </tr>
                  </table>
                  </form>
                  </td>
              </tr>
</table>
          </td>
</table>

