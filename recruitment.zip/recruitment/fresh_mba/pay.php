 <?php
 if(!isset($_SESSION['logged']))
	redirect("index.php?val=allreg");
include_once('include/sql_func.php');
include_once('include/sql_functions.php');
include_once('include/misc_functions.php');
$url=$_SERVER["PHP_SELF"];
include_once('include/sql_func.php');
include_once('include/sql_functions.php');
include_once('include/misc_functions.php');
$connection=new sqlfunctions();
$err_connection=sql_connect_m();
$connection->connect_db("mba_fresh");
$session=2017;	//HARD CODED.... DO SOMETHING ABOUT IT...
$sem=0;	//HARD CODED.... DO SOMETHING ABOUT IT...
$prog='mb';	//HARD CODED.... DO SOMETHING ABOUT IT...
$roll=$_SESSION['roll'];
?>
<center><b style="font-size:18px;">Online Fee Payment</b></center>
<ul class="nav nav-tabs blue-border">
  <li class="active"><a data-toggle="tab" href="#home1" id="pg1">Verify amount to be paid</a></li>
  <li><a data-toggle="tab" href="#menu1" id="pg2">Instructions for Fee Payment</a></li>
</ul>
<?php
	$fee_arr = get_dues($roll);
?>
<div class="tab-content">
      <div id="home1" class="tab-pane fade in active">
        <p class="larger-font2" align="center"><br />
        	<table class="table">
            	<tr>
                	<td> Total amount to be paid :</td>
                    <td> &#8377 <?=$fee_arr['amount']?></td> 
                </tr>
                <tr>
                	<td> You have paid :</td>
                    <td> &#8377 <?=$fee_arr['paid'] ?> </td> 
                </tr>
                <?php
					
					if($fee_arr['due']>0)
					{
						?>
                        <tr>
                            <td> Hence net <strong>Amount Due</strong> is :</td>
                            <td> &#8377 <?=$fee_arr['due'] ?></td> 
                        </tr>
                        <?php
						$query="SELECT `name`,`dob`,`lpno` FROM login as l, per_info as p WHERE l.roll=p.roll and l.roll=?";
						if(!($res3=$connection->prepare($query)))
						{
							log_error($err_connection,$url,$query,$res3,1);
							$connection->close();
							redirect("error_page.html");
						}
						if(!($res3->bind_param("s",$roll)))
						{
							log_error($err_connection,$url,$query,$res3,2);
							$connection->close();
							redirect("error_page.html");
						}
						if($res3->execute())
						{
							$res3->store_result();
							if($res3->num_rows==0)
							{
								$paid=0;
							}
							else
							{
								$res3->bind_result($name,$dob,$lpno);
								$res3->fetch();
							}
						}
						$query="SELECT `value` FROM `tab`.`map` WHERE `code`=?";
						if(!($res3=$connection->prepare($query)))
						{
							log_error($err_connection,$url,$query,$res3,1);
							$connection->close();
							redirect("error_page.html");
						}
						if(!($res3->bind_param("s",$prog)))
						{
							log_error($err_connection,$url,$query,$res3,2);
							$connection->close();
							redirect("error_page.html");
						}
						if($res3->execute())
						{
							$res3->store_result();
							if($res3->num_rows==0)
							{
								$paid=0;
							}
							else
							{
								$res3->bind_result($coursename);
								$res3->fetch();
							}
						}
						?>
            </table>
            		<?php
						if($lpno==''){
							echo '<span class="text-danger">It is mandatory to provide you <strong>Phone No.</strong> in order to proceed with the transaction. Please go to the <strong>Personal Information page</strong> and update your <strong>Phone No.</strong></span>';
						}
						else{
							$ar= array('appid' => $_SESSION['roll'],'name' =>$name,'dob' => $dob,'contact' => $lpno,'prog' =>$coursename,'bra' => 'Not Applicable','amt' => $fee_arr['due'], 'sourcefee'=>'admission','semester'=>$sem,'session'=>"$session");
		 $_SESSION['admission_alldata']=json_encode($ar);
							//print_r($ar);
							echo '<span class="text-important">If the amount shown is correct, you may proceed for payment by clicking the <strong>\'NEXT\'</strong> button on the <strong>instructions page</strong>. But make sure that you read the instructions carefully atleast once.</span>';
						}
					}
					else{
						?>
          </table>
                        <?php
						$ar= array('appid' => $_SESSION['roll'],'name' =>$name,'dob' => $dob,'contact' => $lpno,'prog' =>$coursename,'bra' => 'Not Applicable','amt' => '0', 'sourcefee'=>'admission','semester'=>$sem,'session'=>"$session");
		 				$_SESSION['admission_alldata']=json_encode($ar);
						echo '<span class="text-success">You have already paid your application fees. You may now <strong>take a print out of the forms</strong> and complete the online application process.</span>';
					}
				?>
        </p>
  	</div>
    
    <div id="menu1" class="tab-pane fade">
        <p class="larger-font"><br />
        	<b style="font-size:14px;">Instructions for Fee Payment.</b>
            <strong>Steps:</strong>
            <ul>
            <li>Click on Next (provided below), only if you are ready to pay your FEES</li>
            <li>Check All Your Details and then Click on "Pay" Button.
            </li><li>You will be redirected on SBI MOPS page. Now, Select any of the payment mode and proceed further.
            </li><li>Enter the Required details
            </li><li>Pay the fees and after successful payment you will be shown Success Message.
            </li><li>From the above successful page, now you have to return to Admission Portal by clicking on the link shown below or you will be redirected automatically after some time.
            </li>
            <li>
            <strong>Last step is important otherwise transaction fee will not be  received by the Institute.
            </strong></li>
            </ul>
            <br>
            If you have already generated challan, click here to <a href="https://www.onlinesbi.com/prelogin/mopsremittanceform.htm" target="_blank">reprint</a> it.
            <br><br>
            If you are facing any other problem, then <a href="../support.php">Contact us</a>.
            <br><br>
            <?php 
				if(isset($lpno) && $lpno!=''){
		    		echo "<button class='btn btn-primary' onClick=\"location.href='../admissionfee.php'\">NEXT </button>";
					unset($_SESSION['admission_alldata']);
				}
			?>
		</p>
  	</div>
</div>