<?php
if(!isset($_SESSION['logged']))
	redirect("index.php?val=allreg");
else
{
	$url=$_SERVER["PHP_SELF"];
	include_once('include/sql_func.php');
	include_once('include/sql_functions.php');
	include_once('include/misc_functions.php');
	$connection=new sqlfunctions();
	$err_connection=sql_connect_m();
	$connection->connect_db("mba_fresh");
	$_POST=$connection->sanitize($_POST);
	$query="SELECT name,dob FROM login WHERE roll=?";
	if(!($res=$connection->prepare($query)))
	{
		log_error($err_connection,$url,$query,$res,1);
		$connection->close();
		redirect("error_page.html");
	}
	if(!($res->bind_param("s",$roll)))
	{
		log_error($err_connection,$url,$query,$res,2);
		$connection->close();
		redirect("error_page.html");
	}
	$roll=$_SESSION['roll'];
	if($res->execute())
	{
		$res->store_result();
		$res->bind_result($name,$dob);
		$res->fetch();
		$connection->close();
	}
	else
	{	
		log_error($err_connection,$url,$query,$res,3);
		$connection->close();
		redirect("error_page.html");	
	}
}
?>
<center><b style="font-size:18px;">Upload Photographs</b></center><hr>
<p align="justify" class="larger-font"> 
<ul>
<li>Upload one passport size photograph and one scanned image of your signature.</li>
<li>Only JPEGs of size less than <strong>1MB</strong> are allowed.</li>
</ul>
<hr >
<form class="form" action="<?= $_SERVER['PHP_SELF'] ?>" method="post" enctype="multipart/form-data" >
<div class="row ">
	<div class="col-xs-offset-1 col-xs-4">
    	<p align="center">Photograph</p><hr>
        <?php
			$file="photos/".$_SESSION['roll'].".JPG";
			if(file_exists($file))
			{
				?>
    	<img src="<?= $file ?>" class='img img-responsive img-rounded ' alt="No Photograph found in records..."/><br>
        		<?php
			}
			else
			{
				echo "Please upload a file...<hr>";
			}
				?>
		<input type="file" name="image">
    </div>
    <div class="col-xs-offset-1 col-xs-4">
	    <p align="center">Signature</p><hr>
        <?php
			$file="signature/".$_SESSION['roll'].".JPG";
        if(file_exists($file))
			{
				?>
    	<img src="<?= $file ?>" class='img img-responsive img-rounded ' alt="No Photograph found in records..."/><br>
        		<?php
			}
			else
			{
				echo "Please upload a file...<hr>";
			}
				?>
		<input type="file" name="sign">
    
    </div>
</div>
<div class="row">
	<div class="form-group">
    	<div class="col-sm-offset-4 col-sm-4">
        		<hr>
      		<button type="submit" name="ph_up" class="btn btn-primary col-sm-12">Upload</button>
   	 	</div>
    </div>
</div>
</form>
</p>