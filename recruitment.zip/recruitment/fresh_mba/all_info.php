<html>
<head>
   <title>ALL INFO ABOUT MBA</title>
</head>
<body>
<style>
</style>
<?php
include_once('include/sql_func.php');
include_once('include/sql_functions.php');
include_once('include/misc_functions.php');

$connection=new sqlfunctions();
$err_connection=sql_connect_m();
$connection->connect_db("mba_fresh");
$query="SELECT q.`roll`, `name`,`dob`,`fname`,`mname`,`pwd`,`cat`,`lpno`,`hpno`,`add`,`state`, 
`city`,`pin`,`nationality`,`sex`,`email`,`10board`,`10subject`,`10year`,`10mark`, 
`12board`,`12subject`,`12year`,`12mark`,`13board`,`13subject`,`13year`,`13mark`,
 `14board`,`14subject`,`14year`,`14mark`,`13val`,`14val`,`cat_per` FROM login as l, fees.bank_detail f,
  per_info as p, qualification as q WHERE q.roll =p.roll and l.roll=p.roll and f.regno = q.roll and f.status like '%success%'";

//echo $query;
$s_no=1;
$res=$connection->get_rows($query);
$i=0;
$table='';
$table.='<table align="center" class="table-bordered" border="1">';
$table.='<tr>
	<th> Sno.</th>';	
	$table.='<th>Roll No</th> ';
	$table.='<th>Name</th>
	<th>dob</th>
    <th>fname</th>
    <th>mname</th>
	
	<th>PwD</th>    
    <th>cat</th>
    <th>lpno</th>
    <th>hpno</th>
    <th>add</th>
	<th>state</th>
	<th>city</th>
	<th>pin</th>
	
	 <th>nationality</th>
    <th>sex</th>
    <th>email</th>
   
    <th>10board</th>
	<th>10subject</th>
	<th>10year</th>
	<th>10mark</th>
	
	
    <th>12board</th>
	<th>12subject</th>
	<th>12year</th>
	<th>12mark</th>
	
	
	 <th>13board</th>
	<th>13subject</th>
	<th>13year</th>
	<th>13mark</th>
	
	
	 <th>14board</th>
	<th>14subject</th>
	<th>14year</th>
	<th>14mark</th>
	
	
	 <th>13val</th>
	<th>14val</th>
	<th>cat_per</th>
	
	
		</tr>';
	
	 
	 foreach($res as $key=>$val){
		 $table=$table."<tr>";
		 $len=sizeof($val);
		  $table=$table."<td>".$s_no."</td>";
          $s_no++;
		 for($i=0;$i<$len;$i++)
		   $table=$table."<td>".$val[$i]."</td>";
		   
			  $table=$table."</tr>";
		 
		 }
 echo $table=$table."</table>";
?>

</body>
</html>
	