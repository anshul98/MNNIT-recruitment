<?php
session_start();
require_once ('../included_classes/class_sql.php');
require_once ('../included_classes/class_user.php');
require_once ('../included_classes/class_misc.php');
$sq=new sqlfunctions();
$misc=new miscfunctions();
$sq->connect_db("mba_fresh");
if(!isset($_SESSION['roll']))
{echo "<script>window.location=\"./index.php\"</script>";
		die();	
}
	$q="select step from step where roll=\"$_SESSION[roll]\"";
		$ss=$sq->get_value("step","step","roll",$_SESSION['roll']);
		
		
		if($ss=="1")
		{echo "<script>alert(\"Can't Edit Form Now.\")</script><script>window.location=\"./home.php\"</script>";
		die();}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Dean Academics, MNNIT Allahabad</title>

<link rel="stylesheet" type="text/css" href="../sddm.css" >
<link href="style_test_bk.css" rel="stylesheet" type="text/css" />
<link rel="icon" href="images/MNNIT1.ico" />


<script type="text/javascript">

  var _gaq = _gaq || [];
  _gaq.push(['_setAccount', 'UA-20513375-1']);
  _gaq.push(['_trackPageview']);

  (function() {
    var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
    ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
    var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
  })();

</script>


</head>

<body style="overflow-x:hidden;">
<div id="headerbg">
  <div id="headerblank">
    <div id="header">
      <div id="menu">
        <ul>
         
        </ul>
      </div>
      
    </div>
  </div>
</div>
<div id="head_bot">
</div>
<div id="contentrightblank" style="margin-top:0px; margin-left:120px;">
      <div id="implinks">
        <div class="rightheading" align="center">
          <div class="heading">Contents</div>
        </div><br />


       
        
<div id="leftnav">
	
	<ul>
		<li><a class="leftnav" name="profile" href="./home.php" >Profile</a></li>
	    <li><a class="leftnav" name="profile" href="./index.php?val=elb" >Eligiblity</a></li>
		<li><a class="leftnav" id="midframe" href="./index.php?val=intake">Intake</a></li>
        <li><a class="leftnav" id="midframe" href="./index.php?val=res">Reservation</a></li>
        <li><a class="leftnav1" id="midframe" href="./index.php?val=app">Application and Selection Procedure</a></li>
        
        <li><a class="leftnav" id="midframe" href="./index.php?val=date">Important Dates</a></li>
        <li><a class="leftnav" id="midframe" href="./index.php?val=contact">Contacts</a></li>
		
		</ul>
        

	 </div></div>
    </div>
<div id="contentbg" style="margin-top:-310px;">
  <div id="contentblank">
  
    <div id="content">
     <!---------- <div id="contentleft"> 
     
        <?php $misc->getUpdates();
        ?>
       </div>---->
      <div id="contentmid">
		  <div class="midtxt" align="left" style=" font-size:14px; margin:0px 0 0 0; " >
		        <?php   
			
				include("./editfrmmba.php");  
				
       		   				?>
                               <br />
<br />
<br />
<br />
<br />
<br />
<br />
<br />
				</div>
			 <div id="6" style="display:none;">
              <?php //$user->logout(); ?>
			  
             </div> 
			 
</div>
 <div id="contentrightblank">
      <div id="implinks">
        <div class="rightheading" align="center">
          <div class="heading">Menu</div>
        </div><br />


        
<div id="leftnav">
	
	<ul>
	
	  
	    <li><a class="leftnav" name="profile" href="./printfrm.php" >Print Form</a></li>
		<li><a class="leftnav" id="midframe" href="./home.php">Submit Fee Detail</a></li>
        	<li><a class="leftnav" id="midframe" href="./edit.php">Edit Detail</a></li>
        	<li><a class="leftnav" id="midframe" href="./logout.php">logout</a></li>
		
		</ul>

	 </div></div>
    </div>
  </div></div>
</div>
<?php $misc->getFooter();?>
</body>
</html>
