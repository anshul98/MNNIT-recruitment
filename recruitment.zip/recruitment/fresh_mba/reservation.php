<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Reservation</title>
<style>
.login {
	display:none;
}
#loginbox{
	display:none;
	text-align:center;
	margin:65px 7px -25px 5px;
	padding:25px 5px 15px 55px;
	background:#fff;
	color:#b22d00;
	-moz-border-radius:6px;
	-webkit-border-radius:6px;
}
.submit{
	height:20px;
	width:80px;
}
</style>
</head>

<body>
<div id="main" style="font-size:13px; margin:0px 0 0 0;" align="justify">
  <?php 
			//include('com_header.php'); 
		?>
	
<center><b style="font-size:18px;">Reservation</b></center>
<hr />
<br />
<span class="larger-font">
As per the Government of India requirements, 15% of the seats are reserved for Scheduled Caste

(SC) and 7.5% for Scheduled Tribe (ST) candidates, 27% of the seats are reserved for Other

Backward Classes (OBC) candidates belonging to the &quot;non-creamy&quot; layer. For an updated list of

state-wise OBCs eligible for availing the benefit of reservation, please visit the list maintained by the

NCBC at its website http://ncbc.nic.in/backward-classes/index.html. You may also access information

in respect to the creamy layer at http://ncbc.nic.in/Creamylayer.html. In case of NC-OBC category, the

caste included in the Central List of NC-OBC by the National Council of Backward Classes,

Government of India as on February 22, 2013 (Last date of submitting application form) will be used.

Any subsequent changes will not be effective for admission.
<br><br>
 

As per the provision under Section 39 of the PwD Act, 1995, 3% seats are reserved for Differently

Abled (DA) candidates. The three categories of disability are: (a) Low-vision/blindness, (b) hearing

impairment, and (c) locomotor disability/cerebral palsy. This provision is applicable if the candidate

suffers from any of the listed disabilities to the extent of not less than 40%, as certified by a medical

authority as prescribed and explained in the said Act.
</span>
</div>
</body>
</html>