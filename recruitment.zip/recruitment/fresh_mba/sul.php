 <!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Application and Selection Procedure</title>
<style>
.login {
	display:none;
}
#loginbox{
	display:none;
	text-align:center;
	margin:65px 7px -25px 5px;
	padding:25px 5px 15px 55px;
	background:#fff;
	color:#b22d00;
	-moz-border-radius:6px;
	-webkit-border-radius:6px;
}
.submit{
	height:20px;
	width:80px;
}
</style>
</head>

<body>
<div id="main" style="font-size:13px; margin:0px 0 0 0;" align="justify">

<center><b style="font-size:18px">Selection Procedure</b></center>
<hr />
<p class="larger-font">
  
 Candidates will be short listed for Group Discussion and Personal Interview (GD and PI) on the basis

of CAT Percentile. The MBA Admission Committee may decide the minimum CAT Percentile as short

listing criteria for different categories. Group Discussion (GD) and Personal Interview (PI) will be

conducted at the Institute. Final selection will be made on the basis of CAT percentile and marks

obtained in Group Discussion and Personal Interview. 
</p>
</div>
</body>
</html> 