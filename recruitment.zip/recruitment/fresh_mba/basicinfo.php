<?php
if(!isset($_SESSION['logged']))
	redirect("index.php?val=allreg");
else
{
	$url=$_SERVER["PHP_SELF"];
	include_once('include/sql_func.php');
	include_once('include/sql_functions.php');
	include_once('include/misc_functions.php');
	$connection=new sqlfunctions();
	$err_connection=sql_connect_m();
	$connection->connect_db("mba_fresh");
	$_POST=$connection->sanitize($_POST);
	$query="SELECT name,dob FROM login WHERE roll=?";
	if(!($res=$connection->prepare($query)))
	{
		log_error($err_connection,$url,$query,$res,1);
		$connection->close();
		redirect("error_page.html");
	}
	if(!($res->bind_param("s",$roll)))
	{
		log_error($err_connection,$url,$query,$res,2);
		$connection->close();
		redirect("error_page.html");
	}
	$roll=$_SESSION['roll'];
	if($res->execute())
	{
		$res->store_result();
		$res->bind_result($name,$dob);
		$res->fetch();
		$connection->close();
	}
	else
	{	
		log_error($err_connection,$url,$query,$res,3);
		$connection->close();
		redirect("error_page.html");	
	}
}
?>
<center><b style="font-size:18px;">Basic Information</b></center><hr>
<p align="justify" class="larger-font"> 
<ul>
<li><strong>Basic candidate information is displayed below.</strong></li>
</ul>
<hr >
<form class="form-horizontal"  name="reg_frm" method="post" action="<?= $_SERVER['PHP_SELF'] ?>">
  <div class="form-group">
    <label class="control-label col-sm-3" for="email">CAT Roll No.:</label>
    <div class="col-sm-9">
      <input type="text" class="form-control" placeholder="Enter Your CAT Roll No." id="email" value="<?= $_SESSION['roll'] ?>" name="bas_roll" readonly>
    </div>
  </div>
  <div class="form-group">
    <label class="control-label col-sm-3" for="email">Candidate Name:</label>
    <div class="col-sm-9">
      <input type="text" class="form-control" id="email" placeholder="Enter Your Name" value="<?= $name ?>" name="bas_name" >
    </div>
  </div>
  <div class="form-group">
      <label class="control-label col-sm-3" for="dob">Date of Birth:</label>  
      <div class="col-sm-5">
      <input id="dob" name="bas_dob" value="<?= $dob ?>" placeholder="YYYY-MM-DD" class="form-control input-md"  type="text">
      </div>
  </div>
  <div class="form-group"> 
    <div class="col-sm-offset-4 col-sm-4">
      <button type="submit" name="bas_ch" class="btn btn-primary col-sm-12">Submit Information</button>
    </div>
  </div>
</form>
</p>