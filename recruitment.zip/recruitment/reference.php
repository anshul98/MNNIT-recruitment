<?php
require_once("./included_classes/class_user.php");
    require_once("./included_classes/class_misc.php");
    require_once("./included_classes/class_sql.php");
    $misc= new miscfunctions();
    $db = new sqlfunctions();
   
    $id=$_SESSION['user'];
    $query="SELECT * from `phd_info` where `user_id` like '$id'";
    $r = $db->process_query($query);
    if(mysql_num_rows($r)>0)
    {
     $r = $db->fetch_rows($r);
    $status = validate($r['status']);
    $date = validate($r['date']);
    $title = validate($r['title']);
    $university = validate($r['university']);
}
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Reference</title>
<style>
.login {
  display:none;
}
#loginbox{
  display:none;
  text-align:center;
  margin:65px 7px -25px 5px;
  padding:25px 5px 15px 55px;
  background:#fff;
  color:#b22d00;
  -moz-border-radius:6px;
  -webkit-border-radius:6px;
}
.submit{
  height:20px;
  width:80px;
}
</style>
</head>

<body>
<div id="main" style="font-size:13px; margin:0px 0 0 0;" align="justify">
  <center><b style="font-size:18px;">Reference</b></center>
<hr>
<table class="table table-striped">
  <tr><th>Name</th><th>Designation</th><th>Address</th><th>City</th><th>Pincode</th><th>Mobile</th><th>Email</th><th>Remove</th></tr>
<?php
while(($r = $db->fetch_rows($c)))
    {
  $tmp_id=$r['id'];
  $organisation=validate($r['organisation']);
  $position=validate($r['position']);
  $from=validate($r['from']);
  $to=validate($r['to']);
  $tenure=validate($r['tenure']);
  $pay=validate($r['pay']);
  $nature=validate($r['nature']);
  $emp_type=validate($r['emp_type']);
  
  echo "<tr><td>$organisation</td><td>$position</td><td>$from</td><td>$to</td><td>$pay</td><td>$emp_type</td><td>$nature</td><td>$tenure</td><td><a href='delete.php?id=$tmp_id&page=tech_exp'>Remove</a></td></tr>";
}
  ?>
</table>
<p align="justify" class="larger-font"> 

<ul class="text-danger">
  <li> * Marked fields are mandatory.</li>
</ul>

</script>
<form class="form-horizontal" name="phd_frm" method="post" action="save.php" >
<div class="tab-content">
      <div id="home" class="tab-pane fade in active">
        <h3>Reference</h3>
        <hr>




        <div class="form-group">
          <label class="control-label col-sm-3" for="dob"><span class="text-danger">*</span> Name :</label> 
          <div class="col-sm-3">
            <input type="text" class="form-control"  value="<?php if(isset($name)) echo "$name"; ?>" name="name" required> 
          </div>
            <label class="control-label col-sm-2" for="email"><span class="text-danger">*</span> Designation:</label>
          <div class="col-sm-4">
            <input type="text" class="form-control"  value="<?php if(isset($designation)) echo "$designation"; ?>" name="designation" required> 
          </div>
        </div>




        <div class="form-group">
          <label class="control-label col-sm-3" for="dob"><span class="text-danger">*</span> Address :</label>  
            <div class="col-sm-5">
              <textarea type="text" class="form-control"  value="<?php if(isset($address)) echo "$address"; ?>" name="address" required ></textarea>
            </div>
        </div>


        <div class="form-group">
          <label class="control-label col-sm-3" for="dob"><span class="text-danger">*</span> City :</label> 
          <div class="col-sm-3">
            <input type="text" class="form-control"  value="<?php if(isset($city)) echo "$city"; ?>" name="city" required> 
          </div>
            <label class="control-label col-sm-2" for="email"><span class="text-danger">*</span> Pincode:</label>
          <div class="col-sm-4">
            <input type="text" class="form-control"  value="<?php if(isset($pincode)) echo "$pincode"; ?>" name="pincode" required> 
          </div>
        </div>

        <div class="form-group">
          <label class="control-label col-sm-3" for="dob"><span class="text-danger">*</span> Mobile No. :</label> 
          <div class="col-sm-3">
            <input type="number" class="form-control"  value="<?php if(isset($num)) echo "$num"; ?>" name="num" required> 
          </div>
            <label class="control-label col-sm-2" for="email"><span class="text-danger">*</span> Email:</label>
          <div class="col-sm-4">
            <input type="email" class="form-control"  value="<?php if(isset($email)) echo "$email"; ?>" name="email" required> 
          </div>
        </div>


<div class="form-group"> 
    <div class="col-sm-offset-4 col-sm-4">
      <button type="submit" name="phd_ch" class="btn btn-primary col-sm-12">Submit Information</button>
    </div>
  </div>
  </form>
</div>
</body>
</html>    