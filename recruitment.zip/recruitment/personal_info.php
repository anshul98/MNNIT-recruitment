<?php

require_once("./included_classes/class_user.php");
    require_once("./included_classes/class_misc.php");
    require_once("./included_classes/class_sql.php");
    $misc= new miscfunctions();
    $db = new sqlfunctions();
   
    $id=$_SESSION['user'];
    $dept=array();
    $query="SELECT * from `department` where `user_id` like '$id'";
    $c = $db->process_query($query);
    if(mysql_num_rows($c)>0)
    {
       while($r = $db->fetch_rows($c))
       array_push($dept, $r['dept']);
     }  
$query="SELECT * from `user` where `user_id` like '$id'";
$r = $db->process_query($query);
if(mysql_num_rows($r)>0)
{
  $r = $db->fetch_rows($r);
  $post_applied=$r['post_applied'];
  $specialization=$r['specialization'];
$dolp=validate($r['dolp']);
$name=validate($r['name']);
$dob=validate($r['dob']);
$gender=validate($r['gender']);
$category=validate($r['category']);
$pwd=validate($r['pwd']);
$f_name=validate($r['f_name']);
$m_name=validate($r['m_name']);
$marital_status=validate($r['marital_status']);
$domicile=validate($r['domicile']);
$nationality=validate($r['nationality']);
$minority_status=validate($r['minority_status']);
$no_of_attempts=validate($r['no_of_attempts']);
$place_of_application=validate($r['place_of_application']);
$mobile=validate($r['mobile']);
$address=validate($r['address']);
}

?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Personal Information</title>
<style>
.login {
	display:none;
}
#loginbox{
	display:none;
	text-align:center;
	margin:65px 7px -25px 5px;
	padding:25px 5px 15px 55px;
	background:#fff;
	color:#b22d00;
	-moz-border-radius:6px;
	-webkit-border-radius:6px;
}
.submit{
	height:20px;
	width:80px;
}
</style>
</head>

<body>
<div id="main" style="font-size:13px; margin:0px 0 0 0;" align="justify">
	<center><b style="font-size:18px;">Personal Information</b></center>
<hr>
<p align="justify" class="larger-font"> 

<ul class="text-danger">
  <li> * Marked fields are mandatory.</li>
</ul>

</script>
<form class="form-horizontal" name="reg_frm" method="post" action="save.php" >
<div class="tab-content">
      <div id="home" class="tab-pane fade in active">
        <h3>Personal Details</h3>
        <hr>


        <div class="form-group">
         	<label class="control-label col-sm-3" for="dept"><span class="text-danger">*</span> Department(s) Applied For :</label>  
          	<div class="col-sm-5">
          		<label style="font-weight:400"><input type="checkbox" name="dept[]" value="Advanced Centre for Material Research" <?php if(isset($dept) && in_array('Advanced Centre for Material Research', $dept)) echo 'checked="checked"'; ?> >Advanced Centre for Material Research</label>
          		<label style="font-weight:400"><input type="checkbox" name="dept[]" value="Architecture & Planning" <?php if(isset($dept) &&in_array('Architecture & Planning', $dept)) echo 'checked="checked"'; ?> >Architecture & Planning</label>
          		
          	</div>
      	</div>



      	<div class="form-group">
         	<label class="control-label col-sm-3" for="dob"><span class="text-danger">*</span> Post Applied For :</label>  
          	<div class="col-sm-5">
          		<select name="post_applied" required>
				  <option value="6000" <?php if(isset($post_applied) && $post_applied=='6000') echo 'selected';?> >Assistant Professor AGP-6000</option>
				  <option value="7000" <?php if(isset($post_applied) && $post_applied=='7000') echo 'selected';?> >Assistant Professor AGP-7000</option>
				  <option value="8000" <?php if(isset($post_applied) && $post_applied=='8000') echo 'selected';?> >Assistant Professor AGP-8000</option>
				</select>
          	</div>
      	</div>


      	<div class="form-group">
         	<label class="control-label col-sm-3" for="dob"><span class="text-danger">*</span> Specialization :</label>  
          	<div class="col-sm-5">
          		<input type="text" class="form-control" placeholder="Specialization" required value="<?php if(isset($specialization)) echo "$specialization"; ?>" name="specialization" >
          	</div>
      	</div>


      	<div class="form-group">
         	<label class="control-label col-sm-3" for="dob"><span class="text-danger">*</span> Date of Last Promotion :</label>  
          	<div class="col-sm-5">
          		<input type="date" class="form-control" required value="<?php if(isset($dolp)) echo "$dolp"; ?>" name="dolp" >
          	</div>
      	</div>


      	<div class="form-group">
         	<label class="control-label col-sm-3" for="dob"><span class="text-danger">*</span> Name :</label>  
          	<div class="col-sm-5">
          		<input type="text" class="form-control" required placeholder="Enter your full name" value="<?php if(isset($name)) echo "$name"; ?>" name="name" >
          	</div>
      	</div>


      	<div class="form-group">
         	<label class="control-label col-sm-3" for="dob"><span class="text-danger">*</span> Date of Birth :</label>  
          	<div class="col-sm-5">
          		<input type="date" class="form-control" required value="<?php if(isset($dob)) echo "$dob"; ?>" name="dob" >
          	</div>
      	</div>


        <div class="form-group">
         	<label class="control-label col-sm-3" for="dob"><span class="text-danger">*</span> Gender :</label>  
          	<div class="col-sm-5">
          		<label class="radio-inline"><input type="radio" name="gender" required value="m" <?php if(isset($gender) && $gender=='m') echo 'checked';?> >Male</label>
                <label class="radio-inline"><input type="radio" name="gender" required value="f" <?php if(isset($gender) && $gender=='f') echo 'checked';?>>Female</label>
          	</div>
      	</div>



        <div class="form-group">
         	<label class="control-label col-sm-3" for="dob"><span class="text-danger">*</span> Category:</label>  
          	<div class="col-sm-5">
          		<label class="radio-inline"><input type="radio" name="category" required value="OP" <?php if(isset($category) && strcmp($category,"OP")==0 ) {echo 'checked';}?> >Open</label>
                <label class="radio-inline"><input type="radio" name="category" required value="OBC" <?php if(isset($category) && $category=='OBC') echo 'checked';?> >OBC</label>
                <label class="radio-inline"><input type="radio" name="category" required value="SC" <?php if(isset($category) && $category=='SC') echo 'checked';?> >SC</label>
                <label class="radio-inline"><input type="radio" name="category" required value="ST" <?php if(isset($category) && $category=='ST') echo 'checked';?> >ST</label>
          	</div>
      	</div>


        <div class="form-group">
         	<label class="control-label col-sm-3" for="dob"><span class="text-danger">*</span> Physically Handicapped:</label>
          	<div class="col-sm-5">
          		<label class="radio-inline"><input type="radio" required name="pwd" value="y" <?php if(isset($pwd) && $pwd=='y') echo 'checked';?> >Yes</label>
                <label class="radio-inline"><input type="radio" required name="pwd" value="n" <?php if(isset($pwd) && $pwd=='n') echo 'checked';?> >No</label>
          	</div>
      	</div>


      	<div class="form-group">
        	<label class="control-label col-sm-3" for="email"><span class="text-danger">*</span> Father's Name:</label>
        	<div class="col-sm-9">
         		<input type="text" class="form-control" id="f_name" value="<?php if(isset($f_name)) echo "$f_name"; ?>" placeholder="Enter your father's name here..." name="f_name" required>
        	</div>
      	</div>


        <div class="form-group">
        	<label class="control-label col-sm-3" for="email"><span class="text-danger">*</span>Mother's Name:</label>
        	<div class="col-sm-9">
         		<input type="text" class="form-control" required placeholder="Enter your mother's name here..." value="<?php if(isset($m_name)) echo "$m_name"; ?>" name="m_name">
        	</div>
      	</div>


      	<div class="form-group">
         	<label class="control-label col-sm-3" for="dob"><span class="text-danger">*</span> Marital Status :</label>  
          	<div class="col-sm-5">
          		<select name="marital_status" required>
				  <option value="single" <?php if(isset($marital_status) && $marital_status=='single') echo 'selected';?> >Single</option>
				  <option value="married" <?php if(isset($marital_status) && $marital_status=='married') echo 'selected';?> >Married</option>
				</select>
          	</div>
      	</div>


      	 <div class="form-group">
        	<label class="control-label col-sm-3" for="email"><span class="text-danger">*</span> Domicile:</label>
        	<div class="col-sm-9">
         		<input type="text" class="form-control" placeholder="" required value="<?php if(isset($domicile)) echo "$domicile"; ?>" name="domicile">
        	</div>
      	</div>


      	<div class="form-group">
         	<label class="control-label col-sm-3" for="dob"><span class="text-danger">*</span> Minority Status :</label>  
          	<div class="col-sm-5">
          		<select name="minority_status" required>
				  <option value="na" <?php if(isset($minority_status) && $minority_status=='na') echo 'selected';?> >NA</option>
				  <option value="muslim" <?php if(isset($minority_status) && $minority_status=='muslim') echo 'selected';?> >Muslim</option>
				  <option value="christian"<?php if(isset($minority_status) && $minority_status=='christian') echo 'selected';?> >Christian</option>
				  <option value="sikh" <?php if(isset($minority_status) && $minority_status=='sikh') echo 'selected';?> >Sikh</option>
				  <option value="jain" <?php if(isset($minority_status) && $minority_status=='jain') echo 'selected';?> >Jain</option>
				  <option value="parsi"<?php if(isset($minority_status) && $minority_status=='parsi') echo 'selected';?> >Parsi</option>
				  <option value="buddhist" <?php if(isset($minority_status) && $minority_status=='buddhist') echo 'selected';?> >Buddhist</option>
				</select>
          	</div>
      	</div>


        <div class="form-group">
        	<label class="control-label col-sm-3" for="email"><span class="text-danger">*</span> Mobile No.:</label>
        	<div class="col-sm-9">
         		<input type="text" class="form-control" placeholder="Enter your Mobile No." required value="<?php if(isset($mobile)) echo "$mobile"; ?>" name="mobile" >
        	</div>
      	</div>
      

        <div class="form-group">
        	<label class="control-label col-sm-3" for="email"><span class="text-danger">*</span> Permanent Address:</label>
        	<div class="col-sm-9">
         		<input type="textarea" class="form-control" id="add" required placeholder="Local address lines..." name="address" value="<?php if(isset($address)) echo "$address"; ?>" required>
        	</div>
      	</div>
       
        <div class="form-group">
            <label class="control-label col-sm-3" for="email"><span class="text-danger">*</span> Nationality:</label>
        	<div class="col-sm-4">
         		<input type="text" class="form-control" id="nationality" required placeholder="Nationality" name="nationality" value="<?php if(isset($nationality)) echo "$nationality"; ?>" required>
        	</div>
      	</div>
      	

      	<div class="form-group">
         	<label class="control-label col-sm-3" for="dob"><span class="text-danger">*</span> Number of earlier attempts for this post at MNNIT :</label>  
          	<div class="col-sm-5">
          		<select name="no_of_attempts" required>
				  <option value="0" <?php if(isset($no_of_attempts) && $no_of_attempts=='0') echo 'selected';?> >0</option>
				  <option value="1" <?php if(isset($no_of_attempts) && $no_of_attempts=='1') echo 'selected';?> >1</option>
				  <option value="2" <?php if(isset($no_of_attempts) && $no_of_attempts=='2') echo 'selected';?> >2</option>
				  <option value="3" <?php if(isset($no_of_attempts) && $no_of_attempts=='3') echo 'selected';?> >3</option>
				  <option value="4" <?php if(isset($no_of_attempts) && $no_of_attempts=='4') echo 'selected';?> >4</option>
				  <option value="5" <?php if(isset($no_of_attempts) && $no_of_attempts=='5') echo 'selected';?> >5</option>
				</select>
          	</div>
      	</div>


      	<div class="form-group">
         	<label class="control-label col-sm-3" for="dob"><span class="text-danger">*</span> Port/Place of Applying Application Form :</label>  
          	<div class="col-sm-5">
          		<select name="place_of_application" required>
				  <option value="inside india" <?php if(isset($place_of_application) && $place_of_application=='inside india') echo 'selected';?> >INSIDE INDIA</option>
				  <option value="outside india" <?php if(isset($place_of_application) && $place_of_application=='outside india') echo 'selected';?> >OUTSIDE INDIA</option>
				</select>
          	</div>
      	</div>
        
        
        
</div>
<div class="form-group"> 
    <div class="col-sm-offset-4 col-sm-4">
      <button type="submit" name="per_ch" class="btn btn-primary col-sm-12">Submit Information</button>
    </div>
  </div>
  </form>
</div>
</body>
</html>    