<?php
 require_once("./included_classes/misc_functions.php");
 session_start();
logout("index.php");
?>